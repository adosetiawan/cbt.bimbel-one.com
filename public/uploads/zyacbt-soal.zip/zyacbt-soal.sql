INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES ('9', 'Default', 1);**;**;INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES ('10', 'TIU', 1);**;**;INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES ('11', 'TKP', 1);**;**;INSERT INTO `cbt_modul` (`modul_id`, `modul_nama`, `modul_aktif`) VALUES ('12', 'TWK', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('87', '12', 'TWK 1', 'Tes Wawasan Kebangsaan', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('92', '10', 'MTK', 'Matematika', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('93', '10', 'BHS Indo', 'Bahasa Indonesia', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('94', '10', 'BHS Inggris', 'Bahasa Inggris', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('95', '10', 'PU', 'Pengetahuan Umum', 1);**;**;INSERT INTO `cbt_topik` (`topik_id`, `topik_modul_id`, `topik_nama`, `topik_detail`, `topik_aktif`) VALUES ('96', '9', 'Coba', 'Mencoba', 1);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1768', '87', '<p>Keberagaman antar suku dan golongan dalam kehidupan masyarakat memberikan dampak positif bagi kemajuan negara Indonesia. Salah satu dampak positif yang dapat dirasakan, yaitu .... .</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1769', '87', '<p>Masyarakat wajib menghormati dan menghargai keberagaman suku, agama, ras, antargolongan, bahasa, budaya, dan social sebagai kekayaan bangsa. Masyarakat tidak dibenarkan menonjolkan salah satu keberagaman dan menghina yang lainnya. Pernyataan tersebut sesuai dengan prinsip .... .</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1770', '87', '<p>Memiliki jiwa nasionalis yang diamanatkan oleh Pancasila sesuai dengan semboyan Bhinneka Tunggal Ika harus mengedepankan sikap ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1771', '87', '<p>Semboyan Bhinneka tunggal Ika memiliki nilai historis yang mencerminkan ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1772', '87', '<p>Ketentuan dalam Pasal 30 ayat (1) UUD NRI Tahun 1945 menunjukkan salah satu ciri Bhinneka Tunggal Ika, yaitu ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1773', '87', '<p>Kesadaran akan nasionalisme terkadang membelenggu dan menghambat rakyat dan pemerintahan sendiri. Hal ini bisa terjadi ketika...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1774', '87', '<p>Indonesia adalah Negara yang kaya akan keberagaman, seperti suku dan budaya.Terhadap fakta tersebut kita sebagai warga Negara Indonesia yang menjunjung tinggi persatuan dalam keberagaman seharusnya...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1775', '87', '<p>Lambang negara Indonesia adalah Garuda Pancasila dengan semboyan Bhinneka Tunggal Ika yang ditegaskan dalam pasal 36 A UUD NRI Tahun 1945. Bhinneka Tunggal Ika memiliki ciri-ciri tertentu, salah satunya yaitu ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1776', '87', '<p>Negara Indonesia mengakui keberadaan Tuhan Yang Maha Esa tetapi Indonesia bukan negara agama. Di Indonesia terdapat enam agama yang diakui pemerintah. Terhadap kenyataan ini kita seharusnya ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1777', '87', '<p>Nasionalisme berasal dari bahasa Latin, yaitu <em>nation</em> yang berarti dilahirkan atau sering disebut sebuah bangsa yang dipersatukan akibat kelahiran. Nasionalisme dalam ruang dan waktu dapat memiliki perubahan hakikat karena ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1778', '87', '<p>Salah satu sikap yang mencerminkan nasionalisme dalam pembangunan dibidang ekonomi adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1779', '87', '<p>Pemilihan umum Presiden dan wakil presiden Indonesia dilaksanakan setiap lima tahun sekali. Seluruh rakyat Indonesia, baik suku Batak, Dayak, Jawa, Sunda, maupun Madura berjenis kelamin laki-laki ataupun perempuan yang sudah cukup hukum berhak dan dan wajib memberikan suara dalam pemilihan umum. Hal ini menunjukkan ciri Bhinneka Tunggal ika, yaitu ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1780', '87', '<p>Semua upaya untuk menstransformasi dari keyakinan atau ideologi radikal menjadi tidak radikal dengan pendekatan multi dan interdisipliner (agama, sosial, budaya, dan selainnya) bagi orang yang terpengaruh oleh keyakinan radikal disebut ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1781', '87', '<p>Nasionalisme merupakan sebuah sikap cinta tanah air. Berikut ini yang merupakan ciri-ciri dari nasionalisme adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1782', '87', '<p>Cinta kepada tanah air dan bangsa dapat dibuktikan dengan cara ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1783', '87', '<p>Masyarakat wajib menghrmati dan menghargai keberagaman suku, agama, ras, antargolongan bahasa, budaya, dan social sebagai kekayaan bangsa. Pernyataan tersebut sesuai prinsip persatuan dalam keberagaman masyarakat Indonesia, yaitu ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1784', '87', '<p>Yang dimaksud dengan primodialisme adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1785', '87', '<p>Dina adalah seorang pelajar yang peduli terhadap negaranya. Tidak seperti rekan-rekannya yang mengunggul-unggulkan produk luar negeri, Dina selalu berusaha memakai produk dalam negeri. Bagi Dina menggunakan produk dalam negeri adalah suatu kebanggaan. Sikap yang ditunjukkan oleh Dina adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1786', '87', '<p>Tim dari jurusan Tata Busana SMK N 1 Pandak meraih juara pertama daiam ajang desain busana batik yang diadakan oleh Dinas Pariwisata provinsi DIY. Mengikuti kontes batik tersebut mencerminkan sikap ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1787', '87', '<p>Pak Ahmad sangat menyukai batik, sebagai wujud nyata kecintaannya terhadap batik Pak Ahmad membuka sebuah produksi batik nusantara. Beliau terjun langsung dalam proses pembuatan batik. Selain itu Pak Ahmad juga sangat menekuni setiap proses pembuatan batik nusantara miliknya. Hal ini merupakan contoh ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1788', '87', '<p>Rumusan dan susunan Pancasila yang benar dan sah tercantum dalam ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1789', '87', '<p>Landasan idiil negara kita adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1790', '87', '<p>Lembaga yang secara resmi menerapkan Pancasila sebagai dasar negara adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1791', '87', '<p>Pedoman Penghayatan dan Pengamalan Pancasila ditetapkan pada tanggal ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1792', '87', '<p>Pangkal tolak penghayatan dan pengamalan Pancasila adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1793', '87', '<table>
	<tbody>
		<tr>
			<td>
			<p>Pemilihan kepala daerah secara langsung merupakan penyelenggaraan negara yang sesual dengan nilai pancasila sila ke 4, dalam konstitusi UD1945 pasal 1 ayat 2 kembali menyatakan kedaulatan berada ditangan rakyat. pemilihan kepala daerah merupakan perwujudan dari Pancasila sekaligus pemenuhan terhadap substansi nilai Pancasila, yaitu nilai ....</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1794', '87', '<p>Berikut ini yang bukan merupakan nilai praktis yang ditunjukkan dalam sila Kemanusiaan Yang Adil dan Beradab yang berkaitan dengan HAM adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1795', '87', '<p>Perhatikan pernyataan berikut ini!</p>

<p>1) Unsur-unsur dalam Pancasila belum secara langsung dirumuskan menjadi dasarfilsafat negara</p>

<p>2) Nilai-nilai tersebut terkandung dalam pandangan hidup masyarakat Indonesiasebelum membentuk negara</p>

<p>3) Asal mula tidak langsung Pancasila hakikatnya berasal dari bangsa Indonesia itusendiri</p>

<p>Pernyataan di atas merupakan uraian dari...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1796', '87', '<p>Pancasila sebagai ideologi terbuka harus berorientasi pada masa depan dan mampu melihat semua kemungkinan yang dapat terjadi pada masa sekarang. Berikut ini yang merupakan salah satu unsur ideologi terbuka yang dimiliki oleh Pancasila adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1797', '87', '<p>Pancasila bukan merupakan doktrin, paham yang utopis, dan chauvinisme. Yang dimaksud dengan paham chauvinisme adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1798', '87', '<p>Pancasila sebagai ideologi terbuka memiliki batas-batas sebagai berikut, kecuali ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1799', '87', '<p>Ciri khas paham integralistik Indonesia dapat dilihat dalam kehidupan...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1800', '87', '<p>Paham integralistik yang terkandung dalam Pancasila meletakkan asas kebersamaan&nbsp;hidup, mendambakan keselarasan dalam hubungan baik antara individu maupunmasyarakat. Bila diperinci, paham negara integralistik memiliki pandangan sebagai berikut, kecuali ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1801', '87', '<p>Pengamalan Pancasila sila kelima sebagai paradigma pembangunan adalah .....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1802', '87', '<p>Pancasila sebagai Perjanjian Luhur Bangsa Indonesia memiliki arti ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1803', '87', '<p>Pancasila sudah ada sejak adanya bangsa Indonesia (sejak zaman Sriwijaya dan Majapahit) merupakan pengertian Pancasila sebagai ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1804', '87', '<p style=\"text-align: justify;\">Posisi Indonesia yang strategis menjadikan Indonesia sulit untuk mengindarkan diri dari pengaruh kebudayaan bangsa lain. Sejarah membuktikan, banyak Negara asing memberikan pengaruh kepada budaya kita, tetapi dalam perjalanan sejarah kemudian, pengaruh budaya asing tersebut memunculkan kebiasaan dengan segala akibat negatifnya. Pemahaman Pancasila sangat berperan penting untuk mengatassi permasalahan yang dimaksud, hal ini diwujudkan dengan salah satu fungsi Pancasila dalam menyaring budaya asing adalah sebagai ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1805', '87', '<p>Perhatikan pernyataan berikut ini!</p>

<p>1) Modal pembangunan</p>

<p>2) Satu-satunya asas bagi kehidupan bangsa Indonesia</p>

<p>3) Pendorong terciptanya pembangunan di segala sektor</p>

<p>4) Berasal dari rakyat Indonesia dan negara serumpun yang lain</p>

<p>5) Pandangan hidup bangsa sebelum bangsa Indonesia</p>

<p>6) Cita-cita dan tujuan seluruh bangsa Indonesia</p>

<p>Dari pernyataan di atas yang merupakan fungsi dan peranan Pancasila dalam kehidupan berbangsa dan bernegara Indonesia adalah nomor ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1806', '87', '<p>Salah satu nilai yang terkandung dalam sila keempat Pancasila yaitu .....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1807', '87', '<p>Berikut ini&nbsp;yang merupakan tindakan yang sesuai dengan pengamalan sila ketiga Pancasila, yaitu ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1808', '87', '<p>Pada tanggal 17 Agustus lalu, meskipun masih dalam kondisi pandemi tetapi perayaan hari kemerdekaan tetap terasa nyata. Dimana pemerintah mengundang dan mengajakmasyarakat mengikuti Upacara HUT RI 17 Agustus secara virtual. Mengikuti Upacara HUT RI 17 Agustus menunjukkan sikap ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1809', '87', '<p>Susi similikiti mentaati aturan negera dengan rajin membayar pajak kendaraan bermotor yang dia miliki setiap tahunnya. Sikap susi tersebut menunjukkan sikap ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1810', '87', '<p>Pada hari Minggu Pak Antoni beserta istri dan anak-anaknya ikut turun membersihkan lingkungan sekitar. Karena memang setiap hari Minggu Pahing, RT 05 mengadakan kerja bakti disekitaran wilayah RT 05, mulai dari membersihkan sungai, jalanan dan menyiangi rumput. Ikut serta dalam kegiatan kerja bakti di lingkungan RT mencerminkan sikap ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1811', '87', '<p>Pak Sumarno sangat marah saat mengetahui atlit badminton Indonesia dipaksa <em>walkout</em> di acara All&nbsp;England. Sikap Pak Sumarno tersebut menunjukkan bahwa dia memiliki sikap ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1812', '87', '<p>Pak Sumarno sangat marah menyaksikan keputusan panitia yang mengharuskan atlet badminton Indonesia walkout dari pertandingan All England. Pak Sumarno mengajak para badminton lovers yang tergabung dalam persatuan badminton lovers Indonesia untuk melayangkan protes ke federasi BWF. Sikap Pak Sumarno&nbsp;tersebut mencerminkan sikap ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1813', '87', '<p style=\"text-align: justify;\">Andi adalah bagian dari generasi millenial yang gemar meggunakan internet untuk mengisi waktu. Suatu hari Andi melihat sebuah berita yang menarik perhatiannya di facebook dan langsung membagikannya dilini masa Facebook miliknya, setelah beberapa waktu, salah satu sahabat Andi mengirim pesan dan menyampaikan bahwa berita yang dibagikan oleh andi adalah <em>hoax</em> dan dapat menyulut perpecahan dan dia terancam UU ITE. Tindakan yang dilakukan Andi bertentangan dengan Pancasila khususnya sila ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1814', '87', '<p>Terjadinya demonstrasi besar-besaran diwilayah Propinsi Papua dan Papua barat yang disertai dengan aksi persekusi, pengrusakan dan penjarahan di kantor pemerintahan adalah wujud penerapan penyampaian suara publik dimuka umum yang bertentangan dengan Pancasila khususnya sila ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1815', '87', '<p style=\"text-align: justify;\">Dalam beberapa hari dunia maya kembali dihebohkan dengan video penggerebekan sepasang muda mudi yang diduga tengah berbuat asusila di Cikupa, Tangerang, Banten pada tanggal 20 November 2018. Namun, setelah dilakukan penyelidikan, ternyata pasangan muda mudi tersebut menjadi korban salah tuduh. Video yang viral tersebut memperlihatkan bagaimana para warga mengarak mereka keliling kampung dengan kondisi setengah telanjang. Hal semacam ini telah melanggar sila Pancasila yaitu sila ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1816', '87', '<p style=\"text-align: justify;\">Jumlah tersangka kasus kebakaran hutan dan lahan di Kepulauan Riau per Kamis (19/9/2019) sudah 15 tersangka.Para tersangka itu semuanya merupakan perorangan dan belum terindikasi dari korporasi.Direktur Direktorat Reserse Kriminal Khusus (Ditreskrimsus) Polda Kepri Kombes Rustam Mansur yang juga ketua tim satgas penanggulangan kebakaran hutan dan lahan mengatakan, saat ini ada 15 kasus yang ditangani pihaknya. <em>Sumber : Kompas.com.</em> Dari upaya pemerintah mengamankan pelaku pembakaran hutan sperti yang di informasikan diatas menunjukan bahwa negara ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1817', '87', '<p>Presiden menyinggung masalah pemindahan ibu kota negara, dalam pidatonya pada forum Abu Dhabi Sustainability Week (ADSW) 2020, di Abu Dhabi National Exhibition Centre (ADNEC), Abu Dhabi, Uni Emirat Arab (UEA), Senin (13/01/2020) Presiden mengatakan: pemerintah harus memastikan bahwa gaya hidup perkotaan abad ke-21 rendah karbon dan bertanggung jawab terhadap lingkungan. Ibu kota baru akan mengatasi penyebab sosial pencemaran yaitu budaya gaya hidup boros, dengan menciptakan kota baru yang menarik, mudah, dan diharapkan untuk orang kaya dan miskin. Upaya pemerintah seperti narasi diatas merupakan implementasi dari ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1818', '96', '<p>Apa ya ?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1819', '96', '<p>Siapa ?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1820', '92', '<p>Data berat badan sekelompok siswa tercatat sebagai berikut.<br />
Berat badan (kg) Frekuensi<br />
<img src=\"[base_url]uploads/topik_92/6265f9823be9f.png\" /><br />
Modus dari data tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1821', '92', '<p><img src=\"[base_url]uploads/topik_92/6265f9f4b5e6f.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1822', '92', '<p>Nilai &nbsp;cos 300<sup>0</sup> &minus; tan 45<sup>0</sup> sin 210<sup>0</sup> adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1823', '92', '<p>Fungsi f ( x) dari grafik berikut adalah &hellip;.</p>

<p><img class=\"left\" src=\"[base_url]uploads/topik_92/6265fb21407e6.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1824', '92', '<p>Sebuah ruang tamu berbentuk kubus mempunyai panjang sisi 8 m. salah satu sudut ruang tamu tersebut dibuat dekorasi berbentuk segitiga dengan titik-titik segitiga terletak pada tengah-tengah sisi ruang tamu yang saling bertemu seperti terlihat pada gambar.</p>

<p><img src=\"[base_url]uploads/topik_92/6265fc23b0e76.png\" /></p>

<p>Jarak titik sudut arah diagonal ruang tamu ke bidang segitiga dekorasi tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1825', '92', '<p><img src=\"[base_url]uploads/topik_92/6265fd0729a57.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1826', '92', '<p><img src=\"[base_url]uploads/topik_92/6265fdfba8653.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1827', '92', '<p><img src=\"[base_url]uploads/topik_92/6265ffe4d8390.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1828', '92', '<p>Persamaan lingkaran yang berpusat di (1 , 4) dan melalui titik (&minus;1 , 1) adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1829', '92', '<p>Data nilai matematika siswa kelas XII IPS 1:</p>

<p><img src=\"[base_url]uploads/topik_92/626600cf4f5f5.png\" /></p>

<p>Kuartil bawah dari data pada table tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1830', '92', '<p>Seorang pedagang boneka gemar menata barang dagangannya sehingga Nampak tersusun rapi, variatif, dan menarik pembeli. Dalam suatu etalase barang dengan tipe sama yang diperdagangkannya terdapat 3 boneka warna merah, 4 biru, dan 5 kuning. Jika pedagang menata boneka-boneka tersebut dengan boneka biru harus berdampingan, banyak cara menata ke-12 boneka itu adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1831', '92', '<p>Diketahui matriks&nbsp; <img src=\"[base_url]uploads/topik_92/6266046ab1224.png\" />Jika<em> A<sup>T</sup></em>adalah transpose matriks <em>A </em>, nilai<em> 2a-b</em>&nbsp;yang memenuhi persamaan <em>3 A <sup>T</sup>&minus; B =CD</em> adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1832', '92', '<p>Berikut adalah pengelompokan data gaji pegawai di suatu perusahaan dalam puluhan ribu rupiah dengan menggunakan frekuensi kumulatif lebih dari <em>(F<sub>ki&nbsp;</sub>)</em> .</p>

<p><img src=\"[base_url]uploads/topik_92/626604d82df84.png\" /></p>

<p>Berdasarkan data tersebut, banyak pegawai yang mendapatkan gaji Rp3.000.000,00 sampai dengan Rp3.990.000,00 adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1833', '92', '<p>Seorang pedagang hewan ternak akan menjual sapi dan kambing. Harga seekor sapi dan kambing berturut-turut adalah Rp11.000.000,00 dan Rp1.500.000,00. Modal yang dimilikinya Rp135.000.000,00. Kandang yang ia miliki dapat menampung hewan ternak tidak lebih dari 20 ekor. Model matematika dari permasalahan tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1834', '92', '<p>Daerah yang diarsir adalah daerah himpunan penyelesaian dari suatu masalah program linier</p>

<p><img src=\"[base_url]uploads/topik_92/626605964a49b.png\" /></p>

<p>Model matematika yang sesuai dengan masalah tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1835', '92', '<p>Turunan pertama dari <em>f ( x )= (&minus;2x + 3)<sup>5</sup></em> adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1836', '92', '<p>Suatu partai politik memiliki 5 calon ketua dan 4 orang calon sekretaris. Partai tersebut akan mengirimkan 2 orang calon ketua dan 2 orang calon sekretaris untuk mengikuti pendidikan bela negara. Banyak cara memilih anggota yang akan mengikuti kegiatan tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1837', '92', '<p>Nilai <em>(n)</em> peserta diklat di suatu kelas dihitung dengan rumus <img src=\"[base_url]uploads/topik_92/626607ce91a88.png\" />&nbsp;dimana A nilain keaktifan selama di kelas. Sedangkan nilai keaktifan dihitung dengan rumus <em>y A(P) = 2P + 6 , </em>sedangkan P banyak program kegiatan yang diikuti peserta diklat. Jika Arman adalah salah satu peserta diklat tersebut dan mengikuti 80% dari 20 program kegiatan yang disediakan, nilai yang diperoleh Arman adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1838', '92', '<p>Grafik fungsi<em> f (x) = 2x<sup>3</sup> -3x<sup>3</sup> -</em>72<em>x</em> + 100 naik untuk nilai x yang memenuhi &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1839', '92', '<p>Selembar plat baja berbentuk persegi panjang akan dibuat kotak tanpa tutup dengan cara memotong satu persegi 40 cm &times; 40 cm dari tiap-tiap pojok. Lebar kotak 10 cm kurang dari panjangnya. Dan volume kotak tersebut 3.000 cm<sup>3</sup>. Jika panjang kotak <em>x</em> cm, model matematika permasalahan tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1840', '92', '<p>Diketahui segitiga PQR siku-siku di P dan <img src=\"[base_url]uploads/topik_92/62660f6b1d1b2.png\" />&nbsp;. Nilai tan R adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1841', '92', '<p><img src=\"[base_url]uploads/topik_92/62660fd6aae73.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1842', '92', '<p><img src=\"[base_url]uploads/topik_92/62661075793b6.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1843', '92', '<p>Bentuk yang senilai dengan cot<sup>2</sup>&nbsp;x +1 adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1844', '92', '<p>Modal sebesar Rp6.000.000,00 disimpan di bank dengan bunga tunggal 18% per tahun. Besar modal tersebut setelah satu setengah caturwulan adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1845', '92', '<p>Seorang anak dengan tinggi 160 cm berdiri pada jarak 12 m dari kaki tiang bendera. Jika sudut antara puncak tiang &ndash; anak dan bidang datar adalah 45<sup>0</sup>, tinggi tiang bendera itu adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1846', '92', '<p>Persamaan kuadrat 3<em>x<sup>2</sup> </em>+ m<em>x</em> + 1 = 0 mempunyai akar-akar <em>x<sub>1</sub></em> dan<em> x<sub>2</sub></em> . Jika salah satu akarnya tiga kali akar yang lain maka nilai <em>m</em> yang memenuhi adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1847', '92', '<p>Diketahui kubus ABCD.EFGH dengan panjang sisi 6 cm. Titik P adalah perpotongan diagonal HF dan EG. Jarak dari titik H ke garis DP adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1848', '92', '<p>Dari angka-angka 1, 2, 3, 4, 5, dan 8 akan dibuat bilangan yang terdiri atas tiga angka berlainan dan lebih dari 300. Banyak bilangan yang dapat dibuat adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1849', '92', '<p><img src=\"[base_url]uploads/topik_92/6266134b3a79d.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1850', '92', '<p>Berikut ini akadal pernyataan-pernyataan tentang kubus ABCD.EFGH dengan P, Q, dan R berturutturut titik-titik tengan rusuk AB, DC, dan HG.<br />
(1) Ruas garis PH dan QE bersilangan<br />
(2) Ruas garis RC dan PC tegak lurus.<br />
(3) Ruas garis ER dan PC sejajar.<br />
(4) Segitiga PCR samakaki.<br />
Pernyataan-pernyataan yang benar adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1851', '92', '<p><img src=\"[base_url]uploads/topik_92/626613f965f57.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1852', '92', '<p><img src=\"[base_url]uploads/topik_92/62661452b0584.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1853', '92', '<p><img src=\"[base_url]uploads/topik_92/6266156e06c01.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1854', '92', '<p>Peluang seseorang berhasil mendaki puncak gunung Rinjani 0,78. Jika selamatahun 2015 terdapat 200 orang yang akan mendaki gunung Rinjani maka yang tidak berhasil sampai puncak adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1855', '92', '<p>Sebuah keranjang berisi 4 bola kuning dan 8 bola hijau. Enam bola diambil sekaligus secara acak. Peluang terambil 2 bola kuning dan 4 bola hijau adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1856', '92', '<p><img src=\"[base_url]uploads/topik_92/6266168cc7054.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1857', '92', '<p>Simpangan rata-rata dari data 4, 2, 1, 6, 2 adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1858', '92', '<p><img src=\"[base_url]uploads/topik_92/626617544044b.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1859', '92', '<p><img src=\"[base_url]uploads/topik_92/626617aa52559.png\" /></p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1860', '95', '<p>Alat musik sasando berasal dari provinsi ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1861', '95', '<p>Organisasi Bulutangkis di Indonesia adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1862', '95', '<p>Vaksin Covid-19 yang dikembangkan oleh Universitas Oxford adalah ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1863', '95', '<p>Dia de los Muertos adalah hari perayaan yang berasal dari negara ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1864', '95', '<p>Pengertian Insan Bhayangkara dalam Catur Prasetya adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1865', '95', '<p>Markas Kepolisian ditingkat Kabupaten adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1866', '95', '<p>Ajun Inspektur Polisi Dua adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1867', '95', '<p>Anggota Kepolisian Negara Republik Indonesia adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1868', '95', '<p>Suatu keadaan yang ditandai dengan terjaminnya keamanan dan ketertiban masyarakat, tertib dan tegaknya hukum, serta terselenggaranya perlindungan, pengayoman, dan pelayanan kepada masyarakat, adalah makna &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1869', '95', '<p>Pimpinan Kepolisian Negara Republik Indonesia dan penanggung jawab penyelenggaraan fungsi kepolisian adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1870', '95', '<p>Kapolri diangkat dan diberhentikan oleh Presiden dengan persetujuan &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1871', '95', '<p>Calon Kapolri adalah Perwira Tinggi Kepolisian Negara Republik Indonesia yang masih aktif dengan memperhatikan &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1872', '95', '<p>Tugas pokok Kepolisian Negara Republik Indonesia, kecuali &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1873', '95', '<p>Usia pensiun maksimum anggota Kepolisian Negara Republik Indonesia adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1874', '95', '<p>Menteri Koordinator Bidang Politik, Hukum, dan Keamanan saat ini adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1875', '95', '<p>Unsur pelaksana pendidikan dan staf khusus yang berkenaan dengan pengembangan manajemen Polri adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1876', '95', '<p>Kami Polisi Indonesia menjunjung tinggi nilai kebenaran, keadilan dan kemanusiaan dalam menegakkan hukum negara kesatuan Republik Indonesia yang berdasarkan Pancasila dan Undang-Undang Dasar 1945, adalah isi dari&hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1877', '95', '<p>Hal-hal yang terkandung dalam Catur Prasetya, diantaranya adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1878', '95', '<p>Pejabat Kepolisian Negara Republik Indonesia adalah&hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1879', '95', '<p>Pada tahun 2000, Jenderal Sutarman pernah menjadi Ajudan Presiden RI, yaitu pada masa pemerintahan &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1880', '95', '<p>Kapolri yang menjabat saat ini adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1881', '95', '<p>Nilai dasar yang merupakan pedoman moral dan penuntun nurani bagi setiap anggota Polri serta dapat pula berlaku bagi pengemban fungsi kepolisian lainnya. Adalah makna dari &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1882', '95', '<p>Seorang warga Negara Perancis ingin menjadi anggota Polri, maka :</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1883', '95', '<p>Urutan kepangkatan tingkat Bintara dari yang terendah adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1884', '95', '<p>Wakapolri saat ini adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1885', '95', '<p>Dalam UU No. 2 Tahun 2002 terdapat substansi baru perihal hal ikhwal kepolisian yaitu :</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1886', '95', '<p>Lembaga kepolisian nasional yang disebut dengan Komisi Kepolisian Nasional berkedudukan di bawah dan bertanggung jawab kepada&hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1887', '95', '<p>Syarat menjadi anggota Kepolisian Negara Republik Indonesia adalah, kecuali ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1888', '95', '<p>Undang-undang yang mengatur tentang kepolisian adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1889', '95', '<p>Lambang Polri bernama &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1890', '95', '<p>Arti perisai dalam lambang Polri adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1891', '95', '<p>Wilayah Polda meliputi &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1892', '95', '<p>Akademi kepolisian dipimpin oleh &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1893', '95', '<p>Bhayangkara disebut juga &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1894', '95', '<p>Kapolri pertama dijabat oleh &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1895', '95', '<p>Pangkat Agen Polisi Kelas Dua pada jaman kemerdekaan sekarang setara dengan &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1896', '95', '<p>Berikut beberapa peran kepolisian sebagai alat Negara, kecuali &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1897', '95', '<p>Ir.Soekarno, dalam siding BPUPKI yang pertama, mengusulkan rumusan pancasila yaitu</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1898', '95', '<p>Batas Wilayah Negara Kesatuan Republik Indonesia sebelah Timur adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1899', '95', '<p>Arti insan dalam catur Prasetya &hellip;..</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1900', '95', '<p>Arti Tribrata dalam pengertian baru yang telah menjadi satu suku kata</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1901', '95', '<p>Rektor UGM yang menjadi menteri sekretaris Negara di Kabinet Jokowi-JK.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1902', '95', '<p>Menteri agama sebelum Yaqut Cholil Qoumas adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1903', '95', '<p>Iman Nahrawi pernah menjabat sebagai menteri&hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1904', '95', '<p>Perubahan nama Irian Jaya menjadi Papua Barat dilakukan pada tahun ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1905', '95', '<p>Pertempuran Laut Aru dalam rangka mempertahankan kemerdekaan mengakibatkan tenggelamny akapal ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1906', '95', '<p>Perang Diponegoro terjadi pada tahun ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1907', '95', '<p>Untuk melancarkan penggabungan wilayah Papua bagian barat, Presiden Soekarno mengeluarkan operasi Trikora yang diumumkan di alun alun utara Yogyakarta pada tahun ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1908', '95', '<p>Ibu Kota Sulawesi Tenggara adalah ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1909', '95', '<p>Wakil Presiden RI pada periode 1993-1998 adalah ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1910', '94', '<p><img src=\"[base_url]uploads/topik_94/627495399bd03.png\" /></p>

<p style=\"text-align:justify\">The announcement is about &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1911', '94', '<p><img src=\"[base_url]uploads/topik_94/62749591d8a50.png\" style=\"width: 719px;\" /></p>

<p>The show ends at &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1912', '94', '<p style=\"text-align:justify\">One of the most beautiful of more than 100.000 known species in the order Lepidoptera are the tiger moths, moths known for the striking appeal of their distinctive coloration. This type of moth is covered with highly conspicuous orange and black or yellow patterns of spot and stripes. Such boldly patterned color combinations are commonplace in the animal world, serving the function of forewarning potential predators of unpleasant tastes and smells.</p>

<p style=\"text-align:justify\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; This is unquestionably the function served by the striking coloration of the garden tiger moth, which is quite visually attractive but is also poisonous to predators. Certain glands in the garden tiger moth produce strong toxins that circulate throughout the insect&rsquo;s bloodstream, while other glands secrete bubbles that produce a noxious warning smell. The tiger moth, indeed, is a clear example of a concept that many predators intuitively understand, that creatures with the brightest coloration are often the least suitable to eat.</p>

<p style=\"text-align:justify\">What is the text about?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1913', '94', '<p>One of the most beautiful of more than 100.000 known species in the order Lepidoptera are the tiger moths, moths known for the striking appeal of their distinctive coloration. This type of moth is covered with highly conspicuous orange and black or yellow patterns of spot and stripes. Such boldly patterned color combinations are commonplace in the animal world, serving the function of forewarning potential predators of unpleasant tastes and smells.</p>

<p>This is unquestionably the function served by the striking coloration of the garden tiger moth, which is quite visually attractive but is also poisonous to predators. Certain glands in the garden tiger moth produce strong toxins that circulate throughout the insect&rsquo;s bloodstream, while other glands secrete bubbles that produce a noxious warning smell. The tiger moth, indeed, is a clear example of a concept that many predators intuitively understand, that creatures with the brightest coloration are often the least suitable to eat.</p>

<p>&ldquo;&hellip;.are often the least <strong><u>suitable</u></strong> to eat&rdquo; (last line)</p>

<p>The underlined word means &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1914', '94', '<p>One of the most beautiful of more than 100.000 known species in the order Lepidoptera are the tiger moths, moths known for the striking appeal of their distinctive coloration. This type of moth is covered with highly conspicuous orange and black or yellow patterns of spot and stripes. Such boldly patterned color combinations are commonplace in the animal world, serving the function of forewarning potential predators of unpleasant tastes and smells.</p>

<p>This is unquestionably the function served by the striking coloration of the garden tiger moth, which is quite visually attractive but is also poisonous to predators. Certain glands in the garden tiger moth produce strong toxins that circulate throughout the insect&rsquo;s bloodstream, while other glands secrete bubbles that produce a noxious warning smell. The tiger moth, indeed, is a clear example of a concept that many predators intuitively understand, that creatures with the brightest coloration are often the least suitable to eat.</p>

<p>The main idea of the second paragraph is &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1915', '94', '<table>
	<tbody>
		<tr>
			<td>
			<p>One of the most beautiful of more than 100.000 known species in the order Lepidoptera are the tiger moths, moths known for the striking appeal of their distinctive coloration. This type of moth is covered with highly conspicuous orange and black or yellow patterns of spot and stripes. Such boldly patterned color combinations are commonplace in the animal world, serving the function of forewarning potential predators of unpleasant tastes and smells.</p>

			<p>This is unquestionably the function served by the striking coloration of the garden tiger moth, which is quite visually attractive but is also poisonous to predators. Certain glands in the garden tiger moth produce strong toxins that circulate throughout the insect&rsquo;s bloodstream, while other glands secrete bubbles that produce a noxious warning smell. The tiger moth, indeed, is a clear example of a concept that many predators intuitively understand, that creatures with the brightest coloration are often the least suitable to eat.</p>

			<p>What is the communicative purpose of the text above &hellip;.</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1916', '94', '<p style=\"text-align: justify;\">There are far too many road accidents in this country: too many deaths and too many people injured. One wonders who are the most to blame: drivers or pedestrian.</p>

<p style=\"text-align: justify;\">Many experts are convinced that the larger part of the blame for the death toll must be put on persons and persons alone: drivers who drive too fast and without any consideration for others think that they are safe at the wheel even though they have drunk too much alcohol. These experts also blame the drivers who, out of some curious sense of power, are incapable of understanding that their car is a lethal weapon if it is used improperly.</p>

<p style=\"text-align: justify;\">Pedestrian, likewise, must share guilt. Stepping off the pavement without looking first to the left or right, crossing roads when the traffic lights are against them and jumping off a moving bus are several attitudes that can endanger both pedestrians and driver&rsquo; live.</p>

<p>&ldquo;&hellip;.too many deaths and too many people <u>injured</u>&rdquo;.</p>

<p>What does the underlined word mean?</p>

<p style=\"text-align: justify;\">&nbsp;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1917', '94', '<table>
	<tbody>
		<tr>
			<td>
			<p>There are far too many road accidents in this country: too many deaths and too many people injured. One wonders who are the most to blame: drivers or pedestrian.</p>

			<p>Many experts are convinced that the larger part of the blame for the death toll must be put on persons and persons alone: drivers who drive too fast and without any consideration for others think that they are safe at the wheel even though they have drunk too much alcohol. These experts also blame the drivers who, out of some curious sense of power, are incapable of understanding that their car is a lethal weapon if it is used improperly.</p>

			<p>Pedestrian, likewise, must share guilt. Stepping off the pavement without looking first to the left or right, crossing roads when the traffic lights are against them and jumping off a moving bus are several attitudes that can endanger both pedestrians and driver&rsquo; live.</p>

			<p>What is the communicative purpose of the text above?</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1918', '94', '<p>There are far too many road accidents in this country: too many deaths and too many people injured. One wonders who are the most to blame: drivers or pedestrian.</p>

<p>Many experts are convinced that the larger part of the blame for the death toll must be put on persons and persons alone: drivers who drive too fast and without any consideration for others think that they are safe at the wheel even though they have drunk too much alcohol. These experts also blame the drivers who, out of some curious sense of power, are incapable of understanding that their car is a lethal weapon if it is used improperly.</p>

<p>Pedestrian, likewise, must share guilt. Stepping off the pavement without looking first to the left or right, crossing roads when the traffic lights are against them and jumping off a moving bus are several attitudes that can endanger both pedestrians and driver&rsquo; live.</p>

<p>Why are the pedestrians also responsible for road accidents? Because some of them &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1919', '94', '<p><img src=\"[base_url]uploads/topik_94/6274992e65a84.png\" /></p>

<p>Why does everyone call him Butet?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1920', '94', '<p><img src=\"[base_url]uploads/topik_94/6274992e65a84.png\" /></p>

<p>What sound does he make frequently in class ?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1921', '94', '<p><img src=\"[base_url]uploads/topik_94/6274992e65a84.png\" /></p>

<p>What does the text mainly about?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1922', '94', '<p style=\"text-align:center\"><strong>Indonesia&rsquo;s Biggest Cinematic Achievement</strong></p>

<p style=\"text-align:justify\">I believe there&rsquo;s a huge responsibility in adapting the number 1 best selling novel. The book was certainly popular and everybody worships this work of Andrea Hirata. I didn&rsquo;t expect anything too spectacular from the movie, because as spectacular the book supposedly to be a letdown.</p>

<p style=\"text-align:justify\">Laskar Pelangi is no doubt, one of the best indonesian movies. It beats the Denias: Senandung di Atas Awan, and Ayat-Ayat Cinta (The Verses of Love). It&rsquo;s a 5 star masterpiece in Indonesia, but still deserves 4.5-5 Star in Hollywood stage. The movie contains social and educational issues and strongly declares that everyone needs education and every one needs to be educated. We can learn many life lessons from the movie.</p>

<p style=\"text-align:justify\">I can&rsquo;t stop saying that Laskar Pelangi is a marvelous picture. As a matter of fact, I can&rsquo;t even name a flaw! The casts are perfect, as many of the stars are Indonesian leading and popular actors. Credit to Cut Mini Theo since she brought such a strong performance as a determined teacher. Author Andrea Hirata is a genius since the storyline is beautiful, touching, and engaging at the same time. So get yourself boxes of Kleenex to watch the movie. Thanks to director Riri Riza and producer Mira Lesmana for making the movie good and safe it from being a letdown. Even the author was amazed with the crew&rsquo;s job and statethe movie is better than his original writing. In additions, the movie exposed the scenery in Belitong Island which is beautiful.</p>

<p style=\"text-align:justify\">A testimony: Indonesian President Susilo Bambang Yudhoyono even considered to watch this big motion picture Laskar Pelangi.</p>

<p style=\"text-align:justify\">Andrea Hirata was happy and satisfied because ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1923', '94', '<p style=\"text-align: center;\"><strong>Indonesia&rsquo;s Biggest Cinematic Achievement</strong></p>

<p>I believe there&rsquo;s a huge responsibility in adapting the number 1 best selling novel. The book was certainly popular and everybody worships this work of Andrea Hirata. I didn&rsquo;t expect anything too spectacular from the movie, because as spectacular the book supposedly to be a letdown.</p>

<p>Laskar Pelangi is no doubt, one of the best indonesian movies. It beats the Denias: Senandung di Atas Awan, and Ayat-Ayat Cinta (The Verses of Love). It&rsquo;s a 5 star masterpiece in Indonesia, but still deserves 4.5-5 Star in Hollywood stage. The movie contains social and educational issues and strongly declares that everyone needs education and every one needs to be educated. We can learn many life lessons from the movie.</p>

<p>I can&rsquo;t stop saying that Laskar Pelangi is a marvelous picture. As a matter of fact, I can&rsquo;t even name a flaw! The casts are perfect, as many of the stars are Indonesian leading and popular actors. Credit to Cut Mini Theo since she brought such a strong performance as a determined teacher. Author Andrea Hirata is a genius since the storyline is beautiful, touching, and engaging at the same time. So get yourself boxes of Kleenex to watch the movie. Thanks to director Riri Riza and producer Mira Lesmana for making the movie good and safe it from being a letdown. Even the author was amazed with the crew&rsquo;s job and statethe movie is better than his original writing. In additions, the movie exposed the scenery in Belitong Island which is beautiful.</p>

<p>A testimony: Indonesian President Susilo Bambang Yudhoyono even considered to watch this big motion picture Laskar Pelangi.</p>

<p>Why Laskar Pelangi was considered as one of the best Indonesian movie?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1924', '94', '<p style=\"text-align: center;\"><strong>Indonesia&rsquo;s Biggest Cinematic Achievement</strong></p>

<p>I believe there&rsquo;s a huge responsibility in adapting the number 1 best selling novel. The book was certainly popular and everybody worships this work of Andrea Hirata. I didn&rsquo;t expect anything too spectacular from the movie, because as spectacular the book supposedly to be a letdown.</p>

<p>Laskar Pelangi is no doubt, one of the best indonesian movies. It beats the Denias: Senandung di Atas Awan, and Ayat-Ayat Cinta (The Verses of Love). It&rsquo;s a 5 star masterpiece in Indonesia, but still deserves 4.5-5 Star in Hollywood stage. The movie contains social and educational issues and strongly declares that everyone needs education and every one needs to be educated. We can learn many life lessons from the movie.</p>

<p>I can&rsquo;t stop saying that Laskar Pelangi is a marvelous picture. As a matter of fact, I can&rsquo;t even name a flaw! The casts are perfect, as many of the stars are Indonesian leading and popular actors. Credit to Cut Mini Theo since she brought such a strong performance as a determined teacher. Author Andrea Hirata is a genius since the storyline is beautiful, touching, and engaging at the same time. So get yourself boxes of Kleenex to watch the movie. Thanks to director Riri Riza and producer Mira Lesmana for making the movie good and safe it from being a letdown. Even the author was amazed with the crew&rsquo;s job and statethe movie is better than his original writing. In additions, the movie exposed the scenery in Belitong Island which is beautiful.</p>

<p>A testimony: Indonesian President Susilo Bambang Yudhoyono even considered to watch this big motion picture Laskar Pelangi.</p>

<p>The writer remarked that the movie is very ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1925', '94', '<p style=\"text-align:justify\">Everybody likes home sweet home. However, making an office at home is possible and recommended.&nbsp; Of course home office will have both advantages and disadvantages. Therefore, it is wise to consider the strength and weakness of having a home office.</p>

<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some people will agree that having an office at home will bring benefits. It saves time, we need no commuting which occasionally takes a long time. Besides, we are free to set the work schedule. Having a home office will save money as we need not to purchase or lease an office space. What makes it more flexible is that we can set part of all parts of our home as a real office. What we need is only a wireless router to cover all parts of our house with the internet. We can run our business from any part of house we want, from the living room, bedroom, veranda, etc. we can even make a sale or purchase something. Furthermore, working at home might reduce stress, effort, and save time, and divert it to other more productive things because while working, we are close to our family.</p>

<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; However, making home as an office also has some disadvantages. For some people, keeping the schedule flexible is hard. Such type of people will find it harder working from home. There will be no clear boundaries between work and break. Working from home also reduces the possibility to meet new people. It is true that computer and internet connection relate people anytime and anywhere but we will interact with people only virtually but not in person.</p>

<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; So, considering carefully what we actually need in running a business is much recommended before choosing to have office at home or not.</p>

<p style=\"text-align: justify;\">What does the text tell us about?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1926', '94', '<p>Everybody likes home sweet home. However, making an office at home is possible and recommended.&nbsp; Of course home office will have both advantages and disadvantages. Therefore, it is wise to consider the strength and weakness of having a home office.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some people will agree that having an office at home will bring benefits. It saves time, we need no commuting which occasionally takes a long time. Besides, we are free to set the work schedule. Having a home office will save money as we need not to purchase or lease an office space. What makes it more flexible is that we can set part of all parts of our home as a real office. What we need is only a wireless router to cover all parts of our house with the internet. We can run our business from any part of house we want, from the living room, bedroom, veranda, etc. we can even make a sale or purchase something. Furthermore, working at home might reduce stress, effort, and save time, and divert it to other more productive things because while working, we are close to our family.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; However, making home as an office also has some disadvantages. For some people, keeping the schedule flexible is hard. Such type of people will find it harder working from home. There will be no clear boundaries between work and break. Working from home also reduces the possibility to meet new people. It is true that computer and internet connection relate people anytime and anywhere but we will interact with people only virtually but not in person.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; So, considering carefully what we actually need in running a business is much recommended before choosing to have office at home or not.</p>

<p>Which of the following is the weakness of having an office at home?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1927', '94', '<p>Everybody likes home sweet home. However, making an office at home is possible and recommended.&nbsp; Of course home office will have both advantages and disadvantages. Therefore, it is wise to consider the strength and weakness of having a home office.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some people will agree that having an office at home will bring benefits. It saves time, we need no commuting which occasionally takes a long time. Besides, we are free to set the work schedule. Having a home office will save money as we need not to purchase or lease an office space. What makes it more flexible is that we can set part of all parts of our home as a real office. What we need is only a wireless router to cover all parts of our house with the internet. We can run our business from any part of house we want, from the living room, bedroom, veranda, etc. we can even make a sale or purchase something. Furthermore, working at home might reduce stress, effort, and save time, and divert it to other more productive things because while working, we are close to our family.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; However, making home as an office also has some disadvantages. For some people, keeping the schedule flexible is hard. Such type of people will find it harder working from home. There will be no clear boundaries between work and break. Working from home also reduces the possibility to meet new people. It is true that computer and internet connection relate people anytime and anywhere but we will interact with people only virtually but not in person.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; So, considering carefully what we actually need in running a business is much recommended before choosing to have office at home or not.</p>

<p>Why do people consider working at home can reduce stress, effort and save time?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1928', '94', '<p>Everybody likes home sweet home. However, making an office at home is possible and recommended.&nbsp; Of course home office will have both advantages and disadvantages. Therefore, it is wise to consider the strength and weakness of having a home office.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some people will agree that having an office at home will bring benefits. It saves time, we need no commuting which occasionally takes a long time. Besides, we are free to set the work schedule. Having a home office will save money as we need not to purchase or lease an office space. What makes it more flexible is that we can set part of all parts of our home as a real office. What we need is only a wireless router to cover all parts of our house with the internet. We can run our business from any part of house we want, from the living room, bedroom, veranda, etc. we can even make a sale or purchase something. Furthermore, working at home might reduce stress, effort, and save time, and divert it to other more productive things because while working, we are close to our family.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; However, making home as an office also has some disadvantages. For some people, keeping the schedule flexible is hard. Such type of people will find it harder working from home. There will be no clear boundaries between work and break. Working from home also reduces the possibility to meet new people. It is true that computer and internet connection relate people anytime and anywhere but we will interact with people only virtually but not in person.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; So, considering carefully what we actually need in running a business is much recommended before choosing to have office at home or not.</p>

<p>&ldquo;&hellip;.that having an office at home will bring <strong><u>benefits</u></strong>..&rdquo;. the underlined word has the similar meaning of &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1929', '94', '<p>Everybody likes home sweet home. However, making an office at home is possible and recommended.&nbsp; Of course home office will have both advantages and disadvantages. Therefore, it is wise to consider the strength and weakness of having a home office.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Some people will agree that having an office at home will bring benefits. It saves time, we need no commuting which occasionally takes a long time. Besides, we are free to set the work schedule. Having a home office will save money as we need not to purchase or lease an office space. What makes it more flexible is that we can set part of all parts of our home as a real office. What we need is only a wireless router to cover all parts of our house with the internet. We can run our business from any part of house we want, from the living room, bedroom, veranda, etc. we can even make a sale or purchase something. Furthermore, working at home might reduce stress, effort, and save time, and divert it to other more productive things because while working, we are close to our family.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; However, making home as an office also has some disadvantages. For some people, keeping the schedule flexible is hard. Such type of people will find it harder working from home. There will be no clear boundaries between work and break. Working from home also reduces the possibility to meet new people. It is true that computer and internet connection relate people anytime and anywhere but we will interact with people only virtually but not in person.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; So, considering carefully what we actually need in running a business is much recommended before choosing to have office at home or not.</p>

<p>&ldquo; &hellip;. <strong><u>It</u></strong> saves time, we need no commuting&hellip;&rdquo;. The underlined word refers to &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1930', '94', '<p><img src=\"[base_url]uploads/topik_94/62749c34198d1.png\" /></p>

<p>The text is about selling &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1931', '94', '<p><img src=\"[base_url]uploads/topik_94/62749c34198d1.png\" /></p>

<p>&ldquo;&hellip;.you buy a camera from <strong><u>us</u></strong> before the weekend&hellip;&rdquo;. The underlined word refers to &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1932', '94', '<p><img src=\"[base_url]uploads/topik_94/62749c34198d1.png\" /></p>

<p>DIANA Photography is advertising &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1933', '94', '<p><img src=\"[base_url]uploads/topik_94/62749c34198d1.png\" /></p>

<p>&ldquo; .. <strong><u>Instant </u></strong>pictures.&rdquo; The underlined word has the same meaning as &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1934', '94', '<p style=\"text-align: justify;\">Should we have printed advertisement? There are many reasons for people to answer this question. Many people have strong views and feel that ads are nothing more than useless junk mail, while other people feel it is an important source of information.</p>

<p style=\"text-align: justify;\">Here are some reasons why we should have advertisements in newspapers and magazines. One reason is ads give us information about what is available. Looking at ads we can find out what is on sale and what is new in the market. This is an easy way of shopping. Another reason is that advertisements promote business. When shopkeepers compete against each other, they try to sell their goods as cheap as possible or attract buyers by offering discount. In this case, buyers get the beneficial effects of this competition. They save their money.</p>

<p style=\"text-align: justify;\">On the other hand, some people argue that ads should not be put in newspapers and magazines. Firstly, ads cost the shopkeepers a lot of money to print onto paper. Besides, some people don&rsquo;t like finding junk mail in their letter boxes. People may also find that ads are not very interesting. Ads are not very interesting. Ads also influence people to buy items they don&rsquo;t need and can&rsquo;t really afford. Ads use up a lot of space, and a lot of effort has to be made to make the ads eye-catching.</p>

<p style=\"text-align: justify;\">The text mainly discusses &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1935', '94', '<table>
	<tbody>
		<tr>
			<td>
			<p>Should we have printed advertisement? There are many reasons for people to answer this question. Many people have strong views and feel that ads are nothing more than useless junk mail, while other people feel it is an important source of information.</p>

			<p>Here are some reasons why we should have advertisements in newspapers and magazines. One reason is ads give us information about what is available. Looking at ads we can find out what is on sale and what is new in the market. This is an easy way of shopping. Another reason is that advertisements promote business. When shopkeepers compete against each other, they try to sell their goods as cheap as possible or attract buyers by offering discount. In this case, buyers get the beneficial effects of this competition. They save their money.</p>

			<p>On the other hand, some people argue that ads should not be put in newspapers and magazines. Firstly, ads cost the shopkeepers a lot of money to print onto paper. Besides, some people don&rsquo;t like finding junk mail in their letter boxes. People may also find that ads are not very interesting. Ads are not very interesting. Ads also influence people to buy items they don&rsquo;t need and can&rsquo;t really afford. Ads use up a lot of space, and a lot of effort has to be made to make the ads eye-catching.</p>

			<p>Why do some people agree that advertisement should be printed?</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1936', '94', '<table>
	<tbody>
		<tr>
			<td>
			<p>Should we have printed advertisement? There are many reasons for people to answer this question. Many people have strong views and feel that ads are nothing more than useless junk mail, while other people feel it is an important source of information.</p>

			<p>Here are some reasons why we should have advertisements in newspapers and magazines. One reason is ads give us information about what is available. Looking at ads we can find out what is on sale and what is new in the market. This is an easy way of shopping. Another reason is that advertisements promote business. When shopkeepers compete against each other, they try to sell their goods as cheap as possible or attract buyers by offering discount. In this case, buyers get the beneficial effects of this competition. They save their money.</p>

			<p>On the other hand, some people argue that ads should not be put in newspapers and magazines. Firstly, ads cost the shopkeepers a lot of money to print onto paper. Besides, some people don&rsquo;t like finding junk mail in their letter boxes. People may also find that ads are not very interesting. Ads are not very interesting. Ads also influence people to buy items they don&rsquo;t need and can&rsquo;t really afford. Ads use up a lot of space, and a lot of effort has to be made to make the ads eye-catching.</p>

			<p>Which of the following is a reason why ads are important to consumers?</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1937', '94', '<p>Should we have printed advertisement? There are many reasons for people to answer this question. Many people have strong views and feel that ads are nothing more than useless junk mail, while other people feel it is an important source of information.</p>

<p>Here are some reasons why we should have advertisements in newspapers and magazines. One reason is ads give us information about what is available. Looking at ads we can find out what is on sale and what is new in the market. This is an easy way of shopping. Another reason is that advertisements promote business. When shopkeepers compete against each other, they try to sell their goods as cheap as possible or attract buyers by offering discount. In this case, buyers get the beneficial effects of this competition. They save their money.</p>

<p>On the other hand, some people argue that ads should not be put in newspapers and magazines. Firstly, ads cost the shopkeepers a lot of money to print onto paper. Besides, some people don&rsquo;t like finding junk mail in their letter boxes. People may also find that ads are not very interesting. Ads are not very interesting. Ads also influence people to buy items they don&rsquo;t need and can&rsquo;t really afford. Ads use up a lot of space, and a lot of effort has to be made to make the ads eye-catching.</p>

<p>&ldquo;ads also <u>influence</u> people to buy items &hellip;.&rdquo; (par. 3)</p>

<p>The underlined word is similar to &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1938', '94', '<p>Taman Mini Indonesia Indah (TMII) is a cultured &ndash; based recreational area located in East Jakarta Indonesia. It has an area of about 250 acres. The park is a synopsis of Indonesia culture, with virtually all aspects of daily life in Indonesia&rsquo;s provinces encapsulated in separate pavilions with the collections of architecture, clothing, dances and traditions all depicted impeccably. A part from that, there is a lake with a miniature of archipelago in the middle of it, cable cars, museums, a theatre called Teater Tanah Airku and other recreational facilities which make TMII one of the most popular tourist destinations in the city.</p>

<p>What is the text above?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1939', '94', '<p>Taman Mini Indonesia Indah (TMII) is a cultured &ndash; based recreational area located in East Jakarta Indonesia. It has an area of about 250 acres. The park is a synopsis of Indonesia culture, with virtually all aspects of daily life in Indonesia&rsquo;s provinces encapsulated in separate pavilions with the collections of architecture, clothing, dances and traditions all depicted impeccably. A part from that, there is a lake with a miniature of archipelago in the middle of it, cable cars, museums, a theatre called Teater Tanah Airku and other recreational facilities which make TMII one of the most popular tourist destinations in the city.</p>

<p>How are the aspect s of daily life of Indonesia&rsquo;s province exposed?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1940', '94', '<p>Taman Mini Indonesia Indah (TMII) is a cultured &ndash; based recreational area located in East Jakarta Indonesia. It has an area of about 250 acres. The park is a synopsis of Indonesia culture, with virtually all aspects of daily life in Indonesia&rsquo;s provinces encapsulated in separate pavilions with the collections of architecture, clothing, dances and traditions all depicted impeccably. A part from that, there is a lake with a miniature of archipelago in the middle of it, cable cars, museums, a theatre called Teater Tanah Airku and other recreational facilities which make TMII one of the most popular tourist destinations in the city.</p>

<p>What is the genre of the text above?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1941', '94', '<p>Taman Mini Indonesia Indah (TMII) is a cultured &ndash; based recreational area located in East Jakarta Indonesia. It has an area of about 250 acres. The park is a synopsis of Indonesia culture, with virtually all aspects of daily life in Indonesia&rsquo;s provinces encapsulated in separate pavilions with the collections of architecture, clothing, dances and traditions all depicted impeccably. A part from that, there is a lake with a miniature of archipelago in the middle of it, cable cars, museums, a theatre called Teater Tanah Airku and other recreational facilities which make TMII one of the most popular tourist destinations in the city.</p>

<p>&ldquo;<strong><u>It</u></strong> has an area of about 250 acres&rdquo;. The underlined word refers to?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1942', '94', '<p>Taman Mini Indonesia Indah (TMII) is a cultured &ndash; based recreational area located in East Jakarta Indonesia. It has an area of about 250 acres. The park is a synopsis of Indonesia culture, with virtually all aspects of daily life in Indonesia&rsquo;s provinces encapsulated in separate pavilions with the collections of architecture, clothing, dances and traditions all depicted impeccably. A part from that, there is a lake with a miniature of archipelago in the middle of it, cable cars, museums, a theatre called Teater Tanah Airku and other recreational facilities which make TMII one of the most popular tourist destinations in the city.</p>

<p>&ldquo;The park is a <strong><u>synopsis</u></strong> of Indonesia..&rdquo;. the underlined word has the closest meaning at&hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1943', '94', '<p><img src=\"[base_url]uploads/topik_94/62749fa98903a.png\" /></p>

<p>What is the social function of the text?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1944', '94', '<p><img src=\"[base_url]uploads/topik_94/62749fa98903a.png\" /></p>

<p>The third paragraphs mainly talk about?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1945', '94', '<p><img src=\"[base_url]uploads/topik_94/62749fa98903a.png\" /></p>

<p style=\"text-align:justify\">&quot; ..., so they are often sorted and <strong><u>blended</u></strong> to produce ...&quot;(Paragraph 3)</p>

<p>The underlined word is close in meaning to ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1946', '94', '<p><img src=\"[base_url]uploads/topik_94/62749fa98903a.png\" /></p>

<p>How does the chocolate maker start to make chocolate?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1947', '94', '<p><img src=\"[base_url]uploads/topik_94/62749fa98903a.png\" /></p>

<p>How is the cacao produced into chocolate liquor?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1948', '94', '<p><img src=\"[base_url]uploads/topik_94/6274a10c20cde.png\" /></p>

<p style=\"text-align:justify\">&ldquo; &hellip;. around the world have <strong><u>recognized</u></strong> Palestine.&rdquo; (par 1)</p>

<p>The underlined word means &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1949', '94', '<p><img src=\"[base_url]uploads/topik_94/6274a10c20cde.png\" /></p>

<p>How many NATO members in Europe have recognized Palestine?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1950', '94', '<p><img src=\"[base_url]uploads/topik_94/6274a10c20cde.png\" /></p>

<p>What does the text tells us about?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1951', '94', '<p><img src=\"[base_url]uploads/topik_94/6274a10c20cde.png\" /></p>

<p>&ldquo;&hellip;13 countries formally recognizing <strong><u>it</u></strong> as a state..&rdquo;. the underlined word refers to &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1952', '94', '<p style=\"text-align: justify;\">In the sequel of &lsquo;Sherlock Holmes &lsquo; this time, Professor James Moriarty (Jared Harris) is the most dangerous enemy. Moriarty is not the kind of person who is hesitant to remove the lives of many people in order to achieve his goals. Explosions in Strassbourg are on of the results of Prof. Moriarty&rsquo;s creation.</p>

<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Holmes was nosy when his friend, Dr. Watson ( Jude Law ) was getting married, because the marriage would automatically make Holmes lose his partner in investigating the case.</p>

<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;A gypsy woman, Madam Sinza Heron ( Naomi Rapace ), helped Holmes the adventure this time. There was also the Holmes brother, Mycroft Holmes ( Stephen Fry ) who came to be an accomplice of the detective this time.</p>

<p style=\"text-align: justify;\">Arguably, the visual effect of &lsquo; A Game of Shadow &lsquo; is more stable than its predecessor. A few slow-movement scenes later find in the cease-fire. Colors are display also feels right.</p>

<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Farce as those made by Holmes and several other characters in the film guaranteed to invite laughter. The chemistry between Robert Downey Jr. and Jude Law is not being doubted anymore. Since in the first film, two men were able two captivate the audience and not be missed.</p>

<p style=\"text-align: justify;\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chess compete between Holmes and Prof. Moriarty became the ultimate point. They both describe the mind wanders respectively. Do you intrigued with the acting of the detective? The film &lsquo; Sherlock Holmes&nbsp; A Game of Shadow &lsquo; can be an alternative entertainment at this weekend.</p>

<p style=\"text-align: justify;\">The chemistry between Robert Downey Jr. and Jude Law isn&rsquo;t be doubted because....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1953', '94', '<table>
	<tbody>
		<tr>
			<td>
			<p>In the sequel of &lsquo;Sherlock Holmes &lsquo; this time, Professor James Moriarty (Jared Harris) is the most dangerous enemy. Moriarty is not the kind of person who is hesitant to remove the lives of many people in order to achieve his goals. Explosions in Strassbourg are on of the results of Prof. Moriarty&rsquo;s creation.</p>

			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Holmes was nosy when his friend, Dr. Watson ( Jude Law ) was getting married, because the marriage would automatically make Holmes lose his partner in investigating the case.</p>

			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;A gypsy woman, Madam Sinza Heron ( Naomi Rapace ), helped Holmes the adventure this time. There was also the Holmes brother, Mycroft Holmes ( Stephen Fry ) who came to be an accomplice of the detective this time.</p>

			<p>Arguably, the visual effect of &lsquo; A Game of Shadow &lsquo; is more stable than its predecessor. A few slow-movement scenes later find in the cease-fire. Colors are display also feels right.</p>

			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Farce as those made by Holmes and several other characters in the film guaranteed to invite laughter. The chemistry between Robert Downey Jr. and Jude Law is not being doubted anymore. Since in the first film, two men were able two captivate the audience and not be missed.</p>

			<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chess compete between Holmes and Prof. Moriarty became the ultimate point. They both describe the mind wanders respectively. Do you intrigued with the acting of the detective? The film &lsquo; Sherlock Holmes&nbsp; A Game of Shadow &lsquo; can be an alternative entertainment at this weekend.</p>

			<p>What did the movie director do to invite laughter in his film?</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1954', '94', '<table>
	<tbody>
		<tr>
			<td>
			<table>
				<tbody>
					<tr>
						<td>
						<p>In the sequel of &lsquo;Sherlock Holmes &lsquo; this time, Professor James Moriarty (Jared Harris) is the most dangerous enemy. Moriarty is not the kind of person who is hesitant to remove the lives of many people in order to achieve his goals. Explosions in Strassbourg are on of the results of Prof. Moriarty&rsquo;s creation.</p>

						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Holmes was nosy when his friend, Dr. Watson ( Jude Law ) was getting married, because the marriage would automatically make Holmes lose his partner in investigating the case.</p>

						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;A gypsy woman, Madam Sinza Heron ( Naomi Rapace ), helped Holmes the adventure this time. There was also the Holmes brother, Mycroft Holmes ( Stephen Fry ) who came to be an accomplice of the detective this time.</p>

						<p>Arguably, the visual effect of &lsquo; A Game of Shadow &lsquo; is more stable than its predecessor. A few slow-movement scenes later find in the cease-fire. Colors are display also feels right.</p>

						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Farce as those made by Holmes and several other characters in the film guaranteed to invite laughter. The chemistry between Robert Downey Jr. and Jude Law is not being doubted anymore. Since in the first film, two men were able two captivate the audience and not be missed.</p>

						<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chess compete between Holmes and Prof. Moriarty became the ultimate point. They both describe the mind wanders respectively. Do you intrigued with the acting of the detective? The film &lsquo; Sherlock Holmes&nbsp; A Game of Shadow &lsquo; can be an alternative entertainment at this weekend.</p>

						<p>What can we conclude of &ldquo;A Game of Shadow &rsquo;&rsquo; ?</p>
						</td>
					</tr>
				</tbody>
			</table>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1955', '94', '<p>In the sequel of &lsquo;Sherlock Holmes &lsquo; this time, Professor James Moriarty (Jared Harris) is the most dangerous enemy. Moriarty is not the kind of person who is hesitant to remove the lives of many people in order to achieve his goals. Explosions in Strassbourg are on of the results of Prof. Moriarty&rsquo;s creation.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Holmes was nosy when his friend, Dr. Watson ( Jude Law ) was getting married, because the marriage would automatically make Holmes lose his partner in investigating the case.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;A gypsy woman, Madam Sinza Heron ( Naomi Rapace ), helped Holmes the adventure this time. There was also the Holmes brother, Mycroft Holmes ( Stephen Fry ) who came to be an accomplice of the detective this time.</p>

<p>Arguably, the visual effect of &lsquo; A Game of Shadow &lsquo; is more stable than its predecessor. A few slow-movement scenes later find in the cease-fire. Colors are display also feels right.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Farce as those made by Holmes and several other characters in the film guaranteed to invite laughter. The chemistry between Robert Downey Jr. and Jude Law is not being doubted anymore. Since in the first film, two men were able two captivate the audience and not be missed.</p>

<p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Chess compete between Holmes and Prof. Moriarty became the ultimate point. They both describe the mind wanders respectively. Do you intrigued with the acting of the detective? The film &lsquo; Sherlock Holmes&nbsp; A Game of Shadow &lsquo; can be an alternative entertainment at this weekend.</p>

<p>What is the main idea of the last paragraph?</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1956', '94', '<p>When I&nbsp;<strong>(1) &hellip;.</strong>&nbsp;a boy, I liked swimming very much. Each year my two brothers and I&nbsp;<strong>&hellip;. (2)</strong>the holiday with our uncle and aunt in their house by the sea. It was only twenty yards from the water. The water was warm; the sun shone&nbsp;<strong>&hellip;.(3)</strong>&nbsp;and most days there were no waves. In the middle of the day a wind began to&nbsp;<strong>&hellip;. (4)</strong>&nbsp;but it was not strong and did not make the sea rough.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1957', '94', '<p>When I&nbsp;<strong>(1) &hellip;.</strong>&nbsp;a boy, I liked swimming very much. Each year my two brothers and I&nbsp;<strong>&hellip;. (2)</strong>the holiday with our uncle and aunt in their house by the sea. It was only twenty yards from the water. The water was warm; the sun shone&nbsp;<strong>&hellip;.(3)</strong>&nbsp;and most days there were no waves. In the middle of the day a wind began to&nbsp;<strong>&hellip;. (4)</strong>&nbsp;but it was not strong and did not make the sea rough.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1958', '94', '<p>When I&nbsp;<strong>(1) &hellip;.</strong>&nbsp;a boy, I liked swimming very much. Each year my two brothers and I&nbsp;<strong>&hellip;. (2)</strong>the holiday with our uncle and aunt in their house by the sea. It was only twenty yards from the water. The water was warm; the sun shone&nbsp;<strong>&hellip;.(3)</strong>&nbsp;and most days there were no waves. In the middle of the day a wind began to&nbsp;<strong>&hellip;. (4)</strong>&nbsp;but it was not strong and did not make the sea rough.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1959', '94', '<table>
	<tbody>
		<tr>
			<td>
			<p>When I&nbsp;<strong>(1) &hellip;.</strong>&nbsp;a boy, I liked swimming very much. Each year my two brothers and I&nbsp;<strong>&hellip;. (2)</strong>the holiday with our uncle and aunt in their house by the sea. It was only twenty yards from the water. The water was warm; the sun shone&nbsp;<strong>&hellip;.(3)</strong>&nbsp;and most days there were no waves. In the middle of the day a wind began to&nbsp;<strong>&hellip;. (4)</strong>&nbsp;but it was not strong and did not make the sea rough.</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1960', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b693ae0a4.png\" /></p>

<p>Penyebab konflik dalam kutipan novel tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1961', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b6e0e5cfc.png\" /></p>

<p>Watak Fauzan dalam kutipan novel tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1962', '93', '<p>Perhatikan teks berikut!<br />
1. Personifikasi : Setiap pagi hari alarm handphone bernyanyi membangunkanku dari kesiangan.<br />
2. Simile : Persahabatan kami layaknya rantai yang kokoh.<br />
3. Metafora : Seorang Kutu Buku Menjadi Pemenang Lomba Puisi.<br />
4. Hiperbola : Aku merasa sepi meski di tengah keramaian.<br />
5. Ironi : Wangi sekali bau badanmu<br />
Contoh majas yang tepat terdapat pada nomor ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1963', '93', '<p>(1) Kasihan,&rdquo; desisku dalam hati. Kepada siapa alamat keluhan ini, aku sendiri tidak tahu pasti. Keluhan itu terus sajamenggunung tinggi.<br />
(2) Kepada kedua orang tuaku yang sudah beruban termakan usia? Atau kepada diriku sendiri bersama abangku Tri,yang tak lama lagi kami harus meninggalkan kampong halaman.<br />
(3) Suasana rumah menjadi. Ayah berusaha berbicara setenang mungkin membujuk pribadi tokoh di hadapan anak-anaknya.<br />
(4) &ldquo;Tidak akan saya bekali kalian dengan uang dan berlian. Carilah orang tuamu di rantau. Selalu berbuat kebajikan.Kalau berhasil, jangan lupa membantu saudaramu kelak, &ldquo;ujar ayah pelan.<br />
(5) Suasana mencekam itu membuat hatiku rapuh dan hanyut dalam perasaan sedih yang menyelimuti.<br />
Kalimat bermajas terdapat pada nomor &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1964', '93', '<p>(1) Kasihan,&rdquo; desisku dalam hati. Kepada siapa alamat keluhan ini, aku sendiri tidak tahu pasti. Keluhan itu terus sajamenggunung tinggi.<br />
(2) Kepada kedua orang tuaku yang sudah beruban termakan usia? Atau kepada diriku sendiri bersama abangku Tri,yang tak lama lagi kami harus meninggalkan kampong halaman.<br />
(3) Suasana rumah menjadi. Ayah berusaha berbicara setenang mungkin membujuk pribadi tokoh di hadapan anak-anaknya.<br />
(4) &ldquo;Tidak akan saya bekali kalian dengan uang dan berlian. Carilah orang tuamu di rantau. Selalu berbuat kebajikan.Kalau berhasil, jangan lupa membantu saudaramu kelak, &ldquo;ujar ayah pelan.<br />
(5) Suasana mencekam itu membuat hatiku rapuh dan hanyut dalam perasaan sedih yang menyelimuti.</p>

<p>Konflik yang terdapat pada kutipan tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1965', '93', '<p>Di sebuah gang lengang di basah saya berpapasan dengan seorang perempuan yang muda, wajahnya milik trauma.Kepalanya menunduk, matanya memancarkan duka. Saya urung menyapanya dengan selamat pagi sebab ia tampakcuek sekali. Rasanya saya pernah melihatnya entah di mana. Sebelum saya sempat mengingatnya, tubuhnya keburulenyap ditelan gelapnya malam.<br />
<em>(dikutip: Joko Pinurbo, Sri Menanti)</em></p>

<p><br />
Sudut pandang yang digunakan penulis dalam kutipan cerita tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1966', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b855c5986.png\" /></p>

<p>Amanat yang terkandung dalam kutipan novel tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1967', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b889ecbb7.png\" /></p>

<p>Nilai yang terkandung dalam kutipan novel tersebut adalah nilai &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1968', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b8bf1d5df.png\" /></p>

<p>Berdasarkan kutipan novel di atas, nilai yang sesuai dengan kehidupan sehari-hari adalah ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1969', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b8f285aa7.png\" /></p>

<p>Nilai moral yang terdapat dalam kutipan cerita tersebut adalah &hellip;.</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1970', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b92b8a546.png\" /></p>

<p>Latar tempat yang terdapat dalam penggalan cerita tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1971', '93', '<p><img src=\"[base_url]uploads/topik_93/6274b96593135.png\" /></p>

<p>Kalimat yang membuktikan bahwa tokoh Parsih cemas terdapat pada &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1972', '93', '<p>Perhatikan penggalan novel berikut ini<br />
Seorang lelaki Madura datang. Ia tak dapat dikatakan muda. Tinggi lebih-kurang satu meter enam puluh, umurmendekati empat puluh. Berbaju dan bercelana serba hitam, juga destar pada kepalanya. Sebilah parang pendekterselit pada pinggang. Kumisnya bapang, hitam-kelam, dan tebal. Saat dia senyum pun tidak simetris sehingga terlihatbengis. Mata selalu menatap terbelalak ketika melihat lawan bicaranya.<br />
Penggambaran tokoh seorang tersebut digambarkan secara &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1973', '93', '<p>&ldquo;Ya, itu lagu ciptaanku,&rdquo; jawabku kemudian. Suara tawa terdengar parau.&ldquo;<br />
Hemmm, dasar {...}! Tak kapok juga! sudah berapa kali kami mengintrogasimu? Mengancammu? Memperlakukanmudengan keras<br />
heh?&rdquo;<br />
&ldquo;Aku tak melakukan kesalahan apa-apa!&rdquo; teriakku.<br />
Laki-laki itu menyeringai, sungguh seringai yang tak aku sukai. Bagai serigala yang siap melumat mangsanya!<br />
<em>(Dikutipn dari:Yudhi Herwibawo, Sang Penggesek Biola:Sebuah Roman WR Supratman, Jakarta, Imania, 2018)</em></p>

<p>Majas yang dipakai dalam kalimat kutipan novel sejarah tersebut adalah ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1974', '93', '<p>&ldquo;Ya, itu lagu ciptaanku,&rdquo; jawabku kemudian. Suara tawa terdengar parau.&ldquo;<br />
Hemmm, dasar {...}! Tak kapok juga! sudah berapa kali kami mengintrogasimu? Mengancammu? Memperlakukanmudengan keras<br />
heh?&rdquo;<br />
&ldquo;Aku tak melakukan kesalahan apa-apa!&rdquo; teriakku.<br />
Laki-laki itu menyeringai, sungguh seringai yang tak aku sukai. Bagai serigala yang siap melumat mangsanya!<br />
<em>(Dikutipn dari:Yudhi Herwibawo, Sang Penggesek Biola:Sebuah Roman WR Supratman, Jakarta, Imania, 2018)</em></p>

<p>Ungkapan yang tepat untuk melengkapi kutipan novel sejarah tersebut adalah ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1975', '93', '<p>Perhatikan struktur teks di bawah ini!<br />
(1) Pengenalan situasi cerita (eksposis/orientasi)<br />
(2) Menuju konflik (rising action)<br />
(3) Penyelesaian<br />
(4) Koda<br />
(5) Pengungkapan perisriwa<br />
(6) Puncak konflik<br />
Struktur novel secara berurutan yaitu ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1976', '93', '<p>Namun,<br />
beragama saja tidak cukup. Yang lebih penting lagi adalah beriman. Dan, iman itu akan tercermin dalamperbuatan, perbuatan baik-iman tanpa perbuatan pada hakikatnya adalah mati- termasuk dalam hal ini membangunrelasi dengan saling menghormati itulah yang telah ditunjukkan dalam pertemuan antara kedua pimpinan beragamatersebut. Kita berharp semangat persaudaraan itu mengalir ke segala penjuru dan menghidupi persaudaraan antarumatberiman di mana pun. Tentu termasuk Indonesia.</p>

<p>Keberpihakan penulis adalah kepada &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1977', '93', '<p>Namun,<br />
beragama saja tidak cukup. Yang lebih penting lagi adalah beriman. Dan, iman itu akan tercermin dalamperbuatan, perbuatan baik-iman tanpa perbuatan pada hakikatnya adalah mati- termasuk dalam hal ini membangunrelasi dengan saling menghormati itulah yang telah ditunjukkan dalam pertemuan antara kedua pimpinan beragamatersebut. Kita berharp semangat persaudaraan itu mengalir ke segala penjuru dan menghidupi persaudaraan antarumatberiman di mana pun. Tentu termasuk Indonesia.</p>

<p>Opini penulis pada kutipan tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1978', '93', '<p style=\"text-align: center;\">Boyong Pulang Piala Thomas</p>

<p style=\"text-align: justify;\"><br />
Piala Thomas berhasil diboyong lagi ke Indonesia, setelah 19 tahun jalan-jalan ke negeri asing Malaysia, Jepang,Denmark dan juara bertahan Tiongkok. Perjuangan yang tidak mudah untuk memboyong piala bergengsi di cabangbulutangkis dunia.<br />
(1) Pembinaan cabang olahraga bulutangkis memang bisa menjadi contoh dalam prestasi olahraga di tanah air. (2)Suasana kegembiraan masih terasa meski para pahlawan Piala Thomas malam itu naik podium tanpa pengibaranbendera putih. (3 )Hal tersebut akibat sanksi Badan Antidoping Dunia (WADA). (4) Sanksi bagi Indonesia tersebut,diberlakukan sejak 8 Oktober lalu karena dianggap Indonesia tidak patuh terhadap program tes uji doping. (5) Makabisa disaksikan, meski juara namun tidak diperbolehkan mengibarkan bendera negara, diganti dengan bendera PBSI.(6) Sanksi tersebut masih akan diberlakukan dalam even kalender BWF. (7) Padahal Indonesia menjadi tuan rumah 16Novbember - 5 Desember, Indonesia jadi tuan rumah Asian Leg dan World Tour Finals.</p>

<p style=\"text-align: justify;\">Kalimat berupa opini yang terdapat dalam paragraf dua terdapat pada nomor &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1979', '93', '<p style=\"text-align: center;\">Boyong Pulang Piala Thomas</p>

<p>Piala Thomas berhasil diboyong lagi ke Indonesia, setelah 19 tahun jalan-jalan ke negeri asing Malaysia, Jepang,Denmark dan juara bertahan Tiongkok. Perjuangan yang tidak mudah untuk memboyong piala bergengsi di cabangbulutangkis dunia.<br />
(1) Pembinaan cabang olahraga bulutangkis memang bisa menjadi contoh dalam prestasi olahraga di tanah air. (2)Suasana kegembiraan masih terasa meski para pahlawan Piala Thomas malam itu naik podium tanpa pengibaranbendera putih. (3 )Hal tersebut akibat sanksi Badan Antidoping Dunia (WADA). (4) Sanksi bagi Indonesia tersebut,diberlakukan sejak 8 Oktober lalu karena dianggap Indonesia tidak patuh terhadap program tes uji doping. (5) Makabisa disaksikan, meski juara namun tidak diperbolehkan mengibarkan bendera negara, diganti dengan bendera PBSI.(6) Sanksi tersebut masih akan diberlakukan dalam even kalender BWF. (7) Padahal Indonesia menjadi tuan rumah 16Novbember - 5 Desember, Indonesia jadi tuan rumah Asian Leg dan World Tour Finals.</p>

<p>Isu aktual yang terdapat dalam penggalan teks tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1980', '93', '<p style=\"text-align:center\">Langkah Bijak Atasi Kasus Stunting</p>

<p style=\"text-align:justify\">(1) Stunting, masih menjadi ancaman serius. (2) Bangsa ini bahkan seperti sedang tersadar bila stunting merupakanmasalah besar yang tidak dapat diabaikan. (3) Semua seakan sedang tergagap. (4) Kini fokus program memberbaikikualitas sumberdaya manusia, menghadapi Indonesia Emas yang rasanya tinggal beberapa saat lagi.<br />
(5) Adalah langkah tepat, melaksanakan Gerakan Aksi Bergizi mencegah stunting untuk generasi unggul 8.000Hari Pertama Kehidupan (HPK). (6) Wakil Walikota Heroe Poerwadi menjelaskan, gerakan dilaksanakan denganmembentuk kader remaja di sekolah yang diharap bisa mengingatkan sesama teman, terkait pola asupan makan yangbenar. (7) <strong>Ini</strong> merupakan langkah bijak karena dengan kesadaran tinggi memahami bila perempuan remaja memilikiperan strategis di masa mendatang.<br />
<em>(Sumber KR tanggal 25 Oktober 2021)</em></p>

<p><br />
Makna istilah kader adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1981', '93', '<p style=\"text-align:center\">Langkah Bijak Atasi Kasus Stunting</p>

<p style=\"text-align:justify\">(1) Stunting, masih menjadi ancaman serius. (2) Bangsa ini bahkan seperti sedang tersadar bila stunting merupakanmasalah besar yang tidak dapat diabaikan. (3) Semua seakan sedang tergagap. (4) Kini fokus program memberbaikikualitas sumberdaya manusia, menghadapi Indonesia Emas yang rasanya tinggal beberapa saat lagi.<br />
(5) Adalah langkah tepat, melaksanakan Gerakan Aksi Bergizi mencegah stunting untuk generasi unggul 8.000Hari Pertama Kehidupan (HPK). (6) Wakil Walikota Heroe Poerwadi menjelaskan, gerakan dilaksanakan denganmembentuk kader remaja di sekolah yang diharap bisa mengingatkan sesama teman, terkait pola asupan makan yangbenar. (7) <strong>Ini</strong> merupakan langkah bijak karena dengan kesadaran tinggi memahami bila perempuan remaja memilikiperan strategis di masa mendatang.<br />
<em>(Sumber KR tanggal 25 Oktober 2021)</em></p>

<p style=\"text-align:justify\">Kata ganti &ldquo;ini&rdquo; yang terdapat pada kalimat ke-7 merujuk pada &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1982', '93', '<p style=\"text-align: center;\">Langkah Bijak Atasi Kasus Stunting</p>

<p style=\"text-align: justify;\">(1) Stunting, masih menjadi ancaman serius. (2) Bangsa ini bahkan seperti sedang tersadar bila stunting merupakanmasalah besar yang tidak dapat diabaikan. (3) Semua seakan sedang tergagap. (4) Kini fokus program memberbaikikualitas sumberdaya manusia, menghadapi Indonesia Emas yang rasanya tinggal beberapa saat lagi.<br />
(5) Adalah langkah tepat, melaksanakan Gerakan Aksi Bergizi mencegah stunting untuk generasi unggul 8.000Hari Pertama Kehidupan (HPK). (6) Wakil Walikota Heroe Poerwadi menjelaskan, gerakan dilaksanakan denganmembentuk kader remaja di sekolah yang diharap bisa mengingatkan sesama teman, terkait pola asupan makan yangbenar. (7)&nbsp;<strong>Ini</strong>&nbsp;merupakan langkah bijak karena dengan kesadaran tinggi memahami bila perempuan remaja memilikiperan strategis di masa mendatang.<br />
<em>(Sumber KR tanggal 25 Oktober 2021)</em></p>

<p style=\"text-align: justify;\">Kalimat kausalitas yang terdapat pada teks di atas terdapat pada nomor &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1983', '93', '<p style=\"text-align: center;\">MENYOAL WAJIB PCR PENUMPANG PESAWAT</p>

<p style=\"text-align: justify;\">Syarat wajib tes Polymerase Chain Reaction (PCR) bagi penumpang pesawat terbang, masih menimbulkankontroversi di masyarakat, terutama dari kalangan pelaku pariwisata. Persyaratan tersebut dinilai memberatkanmasyarakat. Selain itu juga tidak mendukung kebangkitan sektor pariwisata yang selama ini sangat terpuruk akibatpandemi Covid-19. Oleh karena itu, muncul usulan agar Surat Edaran Kemenhub No 88 Tahun 2021. Isinya mengatursyarat wajib PCR bagi penumpang pesawat ditinjau kembali.<br />
(1) Banyak pertanyaan yang muncul di masyarakat, misalnya, kalau penumpang pesawat diwajibkan tes PCR,mengapa penumpang di moda transportasi darat, seperti kereta api maupun bus tidak diwajibakan tes PCR? (2) Apakahpotensi bahaya penyebaran virus di pesawat berbeda dengan transportasi darat? (3) Atau jangan-jangan jenis virusberbeda? (4) Kiranya apologi pemerintah yang menyatakan kapasitas pesawat cakupannya lebih luas ketimbang modatransportasi darat sehingga butuh pengamanan khusus yang lebih akurat berupa tes PCR, rasanya kurang relevan. (5)Kita sebut saja moda transportasi kereta api yang kapasitas penumpangnya jauh lebih banyak, tidak perlumensyaratkan tes PCR. <em>&hellip;(Sumber KR tanggal 26 Oktober 2021)</em></p>

<p style=\"text-align: justify;\"><br />
Opini berupa kritik yang terdapat pada paragraf kedua adalah kalimat ke- &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1984', '93', '<p style=\"text-align: center;\">MENYOAL WAJIB PCR PENUMPANG PESAWAT</p>

<p>Syarat wajib tes Polymerase Chain Reaction (PCR) bagi penumpang pesawat terbang, masih menimbulkankontroversi di masyarakat, terutama dari kalangan pelaku pariwisata. Persyaratan tersebut dinilai memberatkanmasyarakat. Selain itu juga tidak mendukung kebangkitan sektor pariwisata yang selama ini sangat terpuruk akibatpandemi Covid-19. Oleh karena itu, muncul usulan agar Surat Edaran Kemenhub No 88 Tahun 2021. Isinya mengatursyarat wajib PCR bagi penumpang pesawat ditinjau kembali.<br />
(1) Banyak pertanyaan yang muncul di masyarakat, misalnya, kalau penumpang pesawat diwajibkan tes PCR,mengapa penumpang di moda transportasi darat, seperti kereta api maupun bus tidak diwajibakan tes PCR? (2) Apakahpotensi bahaya penyebaran virus di pesawat berbeda dengan transportasi darat? (3) Atau jangan-jangan jenis virusberbeda? (4) Kiranya apologi pemerintah yang menyatakan kapasitas pesawat cakupannya lebih luas ketimbang modatransportasi darat sehingga butuh pengamanan khusus yang lebih akurat berupa tes PCR, rasanya kurang relevan. (5)Kita sebut saja moda transportasi kereta api yang kapasitas penumpangnya jauh lebih banyak, tidak perlumensyaratkan tes PCR.&nbsp;<em>&hellip;(Sumber KR tanggal 26 Oktober 2021)</em></p>

<p>Kalimat fakta yang terdapat dalam paragraf satu berjumlah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1985', '93', '<table>
	<tbody>
		<tr>
			<td>
			<p style=\"text-align: center;\">MENYOAL WAJIB PCR PENUMPANG PESAWAT</p>

			<p>Syarat wajib tes Polymerase Chain Reaction (PCR) bagi penumpang pesawat terbang, masih menimbulkankontroversi di masyarakat, terutama dari kalangan pelaku pariwisata. Persyaratan tersebut dinilai memberatkanmasyarakat. Selain itu juga tidak mendukung kebangkitan sektor pariwisata yang selama ini sangat terpuruk akibatpandemi Covid-19. Oleh karena itu, muncul usulan agar Surat Edaran Kemenhub No 88 Tahun 2021. Isinya mengatursyarat wajib PCR bagi penumpang pesawat ditinjau kembali.<br />
			(1) Banyak pertanyaan yang muncul di masyarakat, misalnya, kalau penumpang pesawat diwajibkan tes PCR,mengapa penumpang di moda transportasi darat, seperti kereta api maupun bus tidak diwajibakan tes PCR? (2) Apakahpotensi bahaya penyebaran virus di pesawat berbeda dengan transportasi darat? (3) Atau jangan-jangan jenis virusberbeda? (4) Kiranya apologi pemerintah yang menyatakan kapasitas pesawat cakupannya lebih luas ketimbang modatransportasi darat sehingga butuh pengamanan khusus yang lebih akurat berupa tes PCR, rasanya kurang relevan. (5)Kita sebut saja moda transportasi kereta api yang kapasitas penumpangnya jauh lebih banyak, tidak perlumensyaratkan tes PCR.&nbsp;<em>&hellip;(Sumber KR tanggal 26 Oktober 2021)</em></p>

			<p>Secara berturut-turut struktur kedua paragraf tersebut adalah &hellip;</p>
			</td>
		</tr>
	</tbody>
</table>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1986', '93', '<p>Perhatikan penggalan teks cerita sejarah berikut !<br />
(1) Malam yang senyap menyergap istana Majapahit. (2) Beberapa buah obor telah dinyalakan dan menerangi sudut-sudut istana. (3) Bebera prajurit terlihat berjalan mondar-mandir diregol dan halaman, beberapa yang lain di antaramereka duduk termangu menatap kabut yang turun. (4) Di langit, bulan purnama timbul tenggelam seperti berada diwilayah antara ada dan tiada. (5) Tebalnya kabut akhirnya memberangus gemilang cahayanya menjadi adukan warnaputih yang penuh oleh gumpalan teka-teki tak terjawab.<br />
<em>(Gajah Mada karya Langit Kresna H.).</em><br />
Kalimat yang mengandung makna kiasan terdapat dalam &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1987', '93', '<p>Ki Ageng marah dan mengusir Sunan Kalijaga. Sebelum pergi, Sunan Kalijaga berkata bahwa dia dapatmenunjukkan cara memperoleh kekayaan dengan mudah. Sunan Kalijaga kemudian meminjam cangkul. SunanKalijaga lalu mencangkul tanah di depan kabupaten. Ki Ageng kaget ketika melihat bongkahan emas sebesar kepalakerbau di balik tanah yang dicangkul Sunan Kalijaga.</p>

<p>Kelompok kata kerja material yang terdapat dalam kutipan cerita di atas adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1988', '93', '<p>Ki Ageng marah dan mengusir Sunan Kalijaga. Sebelum pergi, Sunan Kalijaga berkata bahwa dia dapatmenunjukkan cara memperoleh kekayaan dengan mudah. Sunan Kalijaga kemudian meminjam cangkul. SunanKalijaga lalu mencangkul tanah di depan kabupaten. Ki Ageng kaget ketika melihat bongkahan emas sebesar kepalakerbau di balik tanah yang dicangkul Sunan Kalijaga.</p>

<p>Jumlah konjungsi temporal yang terdapat dalam teks tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1989', '93', '<p>Colombo Plan, yang terbentuk pada 1950 dimaksudkan untuk meningkatkan kerjasama ekonomi di Asia Selatan danAsia Tenggara. Akan tetapi, keanggotaannya tidak berasal dari suatu kawasan tertentu dan operasinya bersifatbilatelaral, sehingga tidak sepenuhnya mencerminkan kerja sama regional. Walaupun demikian, keberadaannyabermanfaat untuk memberikan dorongan pentingnya kerja sama regional Asia Tenggara dalam pertemuan konsultatifThe Asia Union di Baguio, Filipina. Pertemuan dimaksudkan agar suara Asia lebih didengar di PBB dan mendorongkerja sama di bidang ekonomi dan sosial antar negara di Asia. Namun, gagasan tersebut tidak berlanjut.<br />
Kesalahan yang terdapat dalam teks tersebut adalah penulisan kata&hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1990', '93', '<p style=\"text-align: justify;\">Colombo Plan, yang terbentuk pada 1950 dimaksudkan untuk meningkatkan kerjasama ekonomi di Asia Selatan danAsia Tenggara. Akan tetapi, keanggotaannya tidak berasal dari suatu kawasan tertentu dan operasinya bersifatbilatelaral, sehingga tidak sepenuhnya mencerminkan kerja sama regional. Walaupun demikian, keberadaannyabermanfaat untuk memberikan dorongan pentingnya kerja sama regional Asia Tenggara dalam pertemuan konsultatifThe Asia Union di Baguio, Filipina. Pertemuan dimaksudkan agar suara Asia lebih didengar di PBB dan mendorongkerja sama di bidang ekonomi dan sosial antar negara di Asia. Namun, gagasan tersebut tidak berlanjut.</p>

<p>Berdasarkan teks tersebut, konjungsi yang memiliki makna pertentangan terdapat dalam kalimat &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1991', '93', '<p style=\"text-align: justify;\">Colombo Plan, yang terbentuk pada 1950 dimaksudkan untuk meningkatkan kerjasama ekonomi di Asia Selatan danAsia Tenggara. Akan tetapi, keanggotaannya tidak berasal dari suatu kawasan tertentu dan operasinya bersifatbilatelaral, sehingga tidak sepenuhnya mencerminkan kerja sama regional. Walaupun demikian, keberadaannyabermanfaat untuk memberikan dorongan pentingnya kerja sama regional Asia Tenggara dalam pertemuan konsultatifThe Asia Union di Baguio, Filipina. Pertemuan dimaksudkan agar suara Asia lebih didengar di PBB dan mendorongkerja sama di bidang ekonomi dan sosial antar negara di Asia. Namun, gagasan tersebut tidak berlanjut.</p>

<p>Ide pokok pada paragraf teks cerita sejarah di atas adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1992', '93', '<p><strong>Perhatikan penggalan teks cerita sejarah berikut!</strong><br />
(1) Lembu Sura menemui Mahesa Sura dengan tangan hampa. (2) Dia menceritakan apa yang terjadi saat dia memintaDewi Tara untuk dipinang Kakaknya secara mendetail. (3) Murkalah Mahesa Sura mendengar penjelasan Lembu Sura.<br />
(4) &ldquo;Kurang ajar para dewata itu! Akan kuhancurkan Kahyangan seperti janjiku dulu! (5) Jika tidak bisa diminta baik-baik, maka akan kuambil dengan jalan apapun!&rdquo; ucap Mahesa Sura.</p>

<p>Ciri kebahasaan berupa kata kerja tuturan seseorang tokoh terdapat pada kalimat ke- &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1993', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c003a14ad.png\" /></p>

<p>Kalimat langsung yang terdapat dalam teks tersebut jika diubah dalam bentuk kalimat tidak langsung yang paling tepatadalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1994', '93', '<p><strong>Perhatikan penggalan teks cerita sejarah berikut!</strong></p>

<p style=\"text-align: justify;\"><br />
Menurut Kitab Carita Parahyangan, Ibukota kerajaan Sunda mula-mula di Galuh, kemudian menurut PrasastiSanghyang Tapak yang ditemukan di tepi sungai Cicatih, Cibadak Sukabumi, Isi dari prasasti itu tentang pembuatandaerah terlarang di sungai itu yang ditandai dengan batu besar di bagian hulu dan hilirnya. Oleh Raja Sri Jayabhupatipenguasa kerajaan Sunda. Di daerah larangan itu orang tidak boleh menangkap ikan dan hewan yang hidup di sungaiitu. Tujuannya untuk menjaga kelestarian lingkungan (agar ikan dan lain-lainnya tidak punah) siapa yang beranimelanggar larangan itu, ia akan dikutuk oleh dewa-dewa.</p>

<p>Dilihat dari strukturnya, penggalan teks cerita sejarah di atas termasuk dalam tahapan ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1995', '93', '<p><strong>Perhatikan penggalan teks cerita sejarah berikut!</strong><br />
Jan Willem menyamping, membuka tangan kanannya, memberi isyarat kepada Danurejo untuk masuk dan duduk.Agaknya untuk penampilan yang berhubungan dengan Bahasa Belanda beschaafdheid yang lebih kurang bermakna&lsquo;tata karma santun sesuai peradaban&rsquo; alih-alih Jan Willem sangat pedui dan hal itu merupakan sisi menarik darinyayang baik di antara sisi-sisi lain yang menyebalkan.....<br />
<em>(Remy Sylado:Pangeran Diponegioro).</em></p>

<p><br />
Nilai yang terkandung dalam kutipan novel tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1996', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c0c462101.png\" /></p>

<p>Ciri kebahasaan teks cerita sejarah yang dominan dalam penggalan tersebut adalah penggunaan &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1997', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c0f8bc3e8.png\" /></p>

<p>Dilihat dari strukturnya, penggalan teks cerita sejarah di atas termasuk dalam tahapan ...</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1998', '93', '<p><strong>Perhatikan penggalan surat lamaran pekerjaan berikut!</strong></p>

<p>Dengan Hormat</p>

<p><br />
Perbaikan penulisan salam pembuka yang salah adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('1999', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c1bc9064c.png\" /></p>

<p>Ciri kebahasaan yang ditunjukkan dengan kata bercetak miring dalam paragraf tersebut adalah penggunaan &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2000', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c346acc19.png\" /></p>

<p>Paragraf tersebut tidak efektif maka perbaikan penulisan yang tepat adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2001', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c38b4c0f9.png\" /></p>

<p>Paragraf di atas merupakan bagian dari ....</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2002', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c3c343cd1.png\" /></p>

<p>Perbaikan penulisan yang tepat adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2003', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c430eec10.png\" /></p>

<p>Penulisan tanggal surat yang tepat adalah&hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2004', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c46790941.png\" /></p>

<p>Jumlah kesalahan dalam penulisan bagian surat tersebut adalah&hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2005', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c48ae5835.png\" /></p>

<p>Berdasarkan lowongan pekerjaan tersebut, penulisan identitas diri pelamar yang paling tepat adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2006', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c4bc57052.png\" /></p>

<p>Berdasarkan lowongan kerja tersebut, tujuan alamat surat lamaran pekerjaan yang paling tepat adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2007', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c55daccc6.png\" /></p>

<p>Secara sistematis, nama bagian-bagian dalam surat lamaran pekerjaan tersebut adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2008', '93', '<p><img src=\"[base_url]uploads/topik_93/6274c5acd2b14.png\" /></p>

<p>Berdasarkan lowongan kerja tersebut, paragraf pembuka surat lamaran pekerjaan yang paling tepat adalah &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_soal` (`soal_id`, `soal_topik_id`, `soal_detail`, `soal_tipe`, `soal_kunci`, `soal_difficulty`, `soal_aktif`, `soal_audio`, `soal_audio_play`, `soal_timer`, `soal_inline_answers`, `soal_auto_next`) VALUES ('2009', '93', '<p>Perhatikan penggalan teks cerita sejarah berikut!<br />
(1) Sejak dulu dia suka keteduhan dan aroma kemuning. (2) Kata orang Jawa, kemuning bermakna<br />
ngemu ening. (3)Artinya, merahimi keheningan. (4) Tapi hari ini, jelas ada yang mengusik ketenangan batinnya dan ketenteraman PuriTegalrejo. (5) Atau bahkan, mengoyak kedamaian seluruh Tanah Jawa.</p>

<p>Ciri kebahasaan penggunaan kalimat bermakna lampau terdapat pada kalimat ke- &hellip;</p>
', 1, NULL, 1, 1, NULL, 0, NULL, 0, 0);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8056', '1768', '<p>Menonjolkan kelebihan suku dan golongan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8057', '1768', '<p>Menumbuhkan konflik dalam masyarakat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8059', '1768', '<p>Menguatkan rasa solidaritas kelompok</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8060', '1768', '<p>Menumbuhkan primodialis menyatukan keberagaman tersebut</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8061', '1768', '<p>Menjadi satu agar tidak menimbulkan konflik</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8062', '1769', '<p>Wawasan nusantara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8063', '1769', '<p>Bhinneka Tunggal Ika</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8064', '1769', '<p>Nasionalisme Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8065', '1769', '<p>Kebebasan yang bertanggung jawab</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8066', '1769', '<p>Bela Negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8067', '1770', '<p>Chauvinisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8068', '1770', '<p>Sukuisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8069', '1770', '<p>Patriotisme</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8070', '1770', '<p>Ekstrimisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8071', '1770', '<p>Etnosentrisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8072', '1771', '<p>Prestasi kerajaan di Indonesia yang pernah menyatukan Nusantara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8073', '1771', '<p>Kejayaan bangsa Indonesia sebelum merdeka</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8074', '1771', '<p>Sikap toleransi terhadap perbedaan telah ada sejak zaman kerajaan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8075', '1771', '<p>Cita-cita luhur bangsa Indonesia yang dimulai sejak zaman Majapahit</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8076', '1771', '<p>Rasa persatuan dahulu dipupuk dengan cara penaklukan yang dilakukan Kerajaan&nbsp;Majapahit dan Sriwijaya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8077', '1772', '<p>Tumbuh dan berkembangnya sikap nasionalisme pada setiap warga negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8078', '1772', '<p>Adanya persamaan hak dan kewajiban bagi setiap warga negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8079', '1772', '<p>Terbinanya sikap saling menghormati antarwarga masyarakat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8080', '1772', '<p>Tidak ada rasialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8081', '1772', '<p>Saling menghormati antar sesama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8082', '1773', '<p>Nasionalisme dipahami secara mendalam sebagai sebuah ideologi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8083', '1773', '<p>Kedudukan nasionalisme semata mata tidak hanya ideologi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8084', '1773', '<p>Sifat universalitas tetap dipegang teguh</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8085', '1773', '<p>Nasionalisme dijadikan sebagai semangat dan semboyan bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8086', '1773', '<p>Jiwa nasionalisme didasarkan pada ideologi bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8087', '1774', '<p>Menumbuhkan sikap toleransi dan menghargai sesama</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8088', '1774', '<p>Menumbuhkan sikap cinta tanah air dengan melakukan asimilasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8089', '1774', '<p>Membanggakan kekayaan suku dan budaya kepada Negara lain</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8090', '1774', '<p>Mempelajari serta mengembangkan semua kebudayaan yang ada</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8091', '1774', '<p>Menumbuhkan sikap peduli terhadap umat seagama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8092', '1775', '<p>Tidak membuka kesempatan berkembangnya rasialisme</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8093', '1775', '<p>Adanya sikap diskriminasi di berbagai bidang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8094', '1775', '<p>Berkembangnya semangat kesukuan dan kedaerahan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8095', '1775', '<p>Tidak adanya persamaan hak dan kewajiban bagi setiap warga negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8096', '1775', '<p>Membuka pintu perdamaian dunia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8097', '1776', '<p>Membina kerukunan hidup antar umat beragama</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8098', '1776', '<p>Menghormati antarumat seagama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8099', '1776', '<p>Mengembangkan sikap saling menghormati antarsesama suku yang beragama sama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8100', '1776', '<p>Menjalin hubungan dalam bingkai kebudayaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8101', '1776', '<p>Menjalin hubungan dalam bingkai kebhinnekaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8102', '1777', '<p>Dipengaruhi oleh sejarah bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8103', '1777', '<p>Disesuaikan dengan penafsiran ideologi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8104', '1777', '<p>Disesuaikan dengan hukum nasional yang berlaku</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8105', '1777', '<p>Adanya gejala sosio politik yang berkembang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8106', '1777', '<p>Mengacu pada gagasan, ide, dan identitas suatu bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8107', '1778', '<p>Mendukung terbentuknya sistem ekonomi pasar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8108', '1778', '<p>Membendung penanaman modal asing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8109', '1778', '<p>Menggalakkan penanaman modal dalam negeri</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8110', '1778', '<p>Mendirikan sistem perekonomian nasional</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8111', '1778', '<p>Membatasi impor kebutuhan pokok</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8112', '1779', '<p>Adanya persamaan hak dan kewajiban bagi setiap warga negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8113', '1779', '<p>Tumbuh dan berkembangnya sikap nasionalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8114', '1779', '<p>Tidak adanya sikap kesukuan dan kedaerahan&nbsp;</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8115', '1779', '<p>Tidak ada rasialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8116', '1779', '<p>Mencerminkan sila kerakyatan yang dipimpin oleh hikmat kebijaksanaan dalam permusyawaratan perwakilan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8117', '1780', '<p>Deradikalisasi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8118', '1780', '<p>Dampak Radikalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8119', '1780', '<p>Naturalisasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8120', '1780', '<p>Nasionalisasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8121', '1780', '<p>Tindakan radikalisasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8122', '1781', '<p>Rela berkorban untuk kepentingan bangsa dan negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8123', '1781', '<p>Berjiwa pembaharuan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8124', '1781', '<p>Tidak mudah menyerah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8125', '1781', '<p>Banggsa berbangsa dan bertanah air indonesia</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8126', '1781', '<p>Rasa cinta tanah air</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8127', '1782', '<p>Mengekspor semua hasil bumi Indonesia dan mengimpor barang luar negeri</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8128', '1782', '<p>Tidak melakukan hubungan dengan negara lain dan melakukan proteksi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8129', '1782', '<p>Menggunakan produksi dalam negeri meskipun tidak mampu membelinya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8130', '1782', '<p>Tidak menggunakan produksi luar negeri meskipun mampu memberinya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8131', '1782', '<p>Mengurangi impor barang dari luar negeri agar devisa tetap stabil</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8132', '1783', '<p>Cinta tanah air Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8133', '1783', '<p>Senasib sepenanggungan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8134', '1783', '<p>Berbeda-beda tetapi tetap satu jua</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8135', '1783', '<p>Masyarakat yang adil dan makmur</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8136', '1783', '<p>Rela berkorban</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8137', '1784', '<p>Paham yang memegang teguh hal-hal yang dibawa sejak kecil baik mengenai adat-istiadat, kepercayaan, maupun tradisi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8138', '1784', '<p>Paham membanggakan bangsanya sendiri atau rasnya sendiri dan menganggap ras/bangsa di luar itu tidak baik</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8139', '1784', '<p>Paham yang mengagungkan budaya asing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8140', '1784', '<p>Paham yang mengikat pengikutnya dengan kepercayaan dan adat istiadat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8141', '1784', '<p>Padam kederahan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8142', '1785', '<p>Nasionalisme</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8143', '1785', '<p>Patriotisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8144', '1785', '<p>Bela negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8145', '1785', '<p>Revolusiner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8146', '1785', '<p>Primodialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8147', '1786', '<p>Nasionalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8148', '1786', '<p>Patriotisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8149', '1786', '<p>Bela negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8150', '1786', '<p>Revolusiner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8151', '1786', '<p>Primodialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8152', '1787', '<p>Nasionalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8153', '1787', '<p>Revolusioner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8154', '1787', '<p>Patriotisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8155', '1787', '<p>Bela negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8156', '1787', '<p>Cinta bangsa dan negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8157', '1788', '<p>Pidato Moh. Yamin tanggal 29 Mei 1945</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8158', '1788', '<p>Piagam Jakarta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8159', '1788', '<p>Pidato Bung Karno tanggal 1 Juni 1945</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8160', '1788', '<p>Pembukaan UUD 1945</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8161', '1788', '<p>Mukadimah Konstitusi Sementara RIS</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8162', '1789', '<p>Tap MPR</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8163', '1789', '<p>UUD 1945</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8164', '1789', '<p>Pancasila</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8165', '1789', '<p>Proklamasi Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8166', '1789', '<p>Keputusan Presiden</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8167', '1790', '<p>BPUPKI</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8168', '1790', '<p>PPKI</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8169', '1790', '<p>KNIP</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8170', '1790', '<p>MPR</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8171', '1790', '<p>Presiden</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8172', '1791', '<p>12 Maret 1978</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8173', '1791', '<p>14 Maret 1978</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8174', '1791', '<p>2 Maret 1978</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8175', '1791', '<p>22 Maret 1978</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8176', '1791', '<p>4 Maret 1978</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8177', '1792', '<p>Keamuan dan kemampuan manusia Indonesia dalam mengembangkan kebudayaan asing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8178', '1792', '<p>Kemauan dan kemampuan mengembangkan pertengkaran antar suku</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8179', '1792', '<p>Kemauan dan kemampuan mengadakan tuntutan dan kebutuhan masyarakat modern</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8180', '1792', '<p>Kemauan dan kemampuan manusia Indonesia dalam mengendalikan diri</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8181', '1792', '<p>Kemauan dan kemampuan manusia Indonesia menjaga Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8183', '1793', '<p>Dasar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8184', '1793', '<p>Instrumental</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8185', '1793', '<p>Praksis</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8186', '1793', '<p>Estetika</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8187', '1793', '<p>Etika</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8192', '1794', '<p>Mengakui persamaan hak dan kewajiban antar sesama manusia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8188', '1794', '<p>Berani membela kebenaran dan keadilan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8189', '1794', '<p>Cinta tanah air dan bangsa</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8190', '1794', '<p>Menjunjung tinggi nilai&mdash;nilai kemanusiaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8191', '1794', '<p>Tenggang rasa pada orang lain</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8193', '1795', '<p>Asal Mula Tujuan Pancasila</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8194', '1795', '<p>Asal Mula Bahan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8195', '1795', '<p>Asal Mula Bentuk</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8196', '1795', '<p>Asal Mula Tidak Langsung</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8197', '1795', '<p>Asal Mula Karya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8198', '1796', '<p>Dasar yang digunakan adalah keinginan perseorangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8199', '1796', '<p>Nilai dan cita-cita yang ada berasal dari pribadi bangsa itu sendiri</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8200', '1796', '<p>Isinya bisa langsung dilaksanakan tanpa ada penjelasan lebih dalam</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8201', '1796', '<p>Merupakan hasil kombinasi dengan kebudayaan lain</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8202', '1796', '<p>Bersumber dari budaya dan nilai kehidupan suatu daerah/kelompok mayoritas</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8203', '1797', '<p>Cinta tanah air yang berlebihan dengan mengagungkan ciri sendir1 dan merendahkan bangsa lain</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8204', '1797', '<p>Perpaduan dari paham-paham atau aliran-aliran agama kepercayaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8205', '1797', '<p>Kebebasan dan persamaan hak</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8206', '1797', '<p>Suku dan bangsanya lebih baik dari suku bangsa manapun</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8207', '1797', '<p>Cinta tanah air dan rela berkorban demi tanah air</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8208', '1798', '<p>Mencegah berkembangnya paham dan ideologi liberal</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8209', '1798', '<p>Penciptaan norma baru tidak perlu memiliki konsensus</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8210', '1798', '<p>Larangan terhadap ideologi Marxisme, Leninisme, dan Komunisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8211', '1798', '<p>Larangan terhadap pandangan ekstrem yang meresahkan masyarakat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8212', '1798', '<p>Menekankan pada stabilitas nasional yang sehat dan dinamis</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8213', '1799', '<p>Perkotaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8214', '1799', '<p>Organisasi kedaerahan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8215', '1799', '<p>Pemerintahan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8216', '1799', '<p>Pedesaan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8217', '1799', '<p>Organisasi Keagamaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8218', '1800', '<p>Negara tidak memihak kepada suatu golongan atau perseorangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8219', '1800', '<p>Negara menganggap kepentingan seseorang sebagai pusat</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8220', '1800', '<p>Negara tidak hanya menjamin kepentingan seseorang atau golongan tertentu saja</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8221', '1800', '<p>Negara menjamin kepentingan masyarakat seluruhnya sebagai suatu kesatuan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8222', '1800', '<p>Negara menjamin keselamatan hidup bangsa seluruhnya sebagai suatu kesatuan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8223', '1801', '<p>Menumbuhkembangkan sistem politik demokrasi Pancasila yang mampu memelihara stabilitas nasional yang dinamis</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8224', '1801', '<p>Pengembangan ekonomi dan pemerataan pembangunan serta mengembangkan kesadaran dan tanggung jawab warga negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8225', '1801', '<p>Upaya mengembangkan pertumbuhan ekonomi dan pemerataan pembangunan dan hasil-hasilnya sehingga tercipta kemakmuran yang berkeadilan bagi rakyat Indonesia</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8226', '1801', '<p>Peningkatan harkat dan martabat serta kewajiban asasi warga negara dan penghapusan ketidakadilan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8227', '1801', '<p>Pembangunan untuk meningkatkan harkat artabat manusia berdasarkan nilai kodrat manusia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8228', '1802', '<p>Melindungi segenap bangsa dan seluruh tumpah darah Indonesia, memajukan kesejahteraan umum dan mencerdaskan kehidupan bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8229', '1802', '<p>Pancasila yang ada sejak negara Indonesia berdiri dan kemerdekaan bangsa Indonesia sebagai perwujudan dari hak asasi manusia</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8230', '1802', '<p>Pancasila sebagai pemersatu bangsa Indonesia yang serba majemukan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8231', '1802', '<p>Pancasila sebagai dasar untuk mengatur pemerintahan negara atau untuk mengatur penyelenggaraan negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8232', '1802', '<p>Pancasila sebagai pedoman tingkah laku atau petunjuk bagi setiap warga negara Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8233', '1803', '<p>Pandangan Hidup Bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8234', '1803', '<p>Kepribadian Bangsa Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8235', '1803', '<p>Sumber Hukum</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8236', '1803', '<p>Jiwa Bangsa Indonesia</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8237', '1803', '<p>Perjanjian Luhur</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8238', '1804', '<p>Perjanjian luhur bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8239', '1804', '<p>Dasar negara Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8240', '1804', '<p>Fuilsafat hidup bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8241', '1804', '<p>Etika hidup bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8242', '1804', '<p>Kepribadian bangsa</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8243', '1805', '<p>1,2,3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8244', '1805', '<p>2,3,4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8245', '1805', '<p>3,4,5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8246', '1805', '<p>4,5,6</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8247', '1805', '<p>1,2, 6</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8248', '1806', '<p>Persatuan dan kesatuan dalam arti ideologis, ekonomi, politik, sosial, budaya, dan keamanan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8249', '1806', '<p>Adanya konsep nilai kemanusiaan yang lengkap, adil, dan bermutu tinggi karena kemampuannya berbudaya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8250', '1806', '<p>Merupakan bentuk keyakinan yang berpangkal dari kesadaran manusia sebagai makhluk Tuhan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8251', '1806', '<p>Keputusan yang diambil harus dapat dipertanggungjawabkan secara moral kepada Tuhan YME, menjunjung tinggi harkat dan artabat manusia, nilai-nila1 kebenaran dan keadilan mengutamakan persatuan dan kesatuan demi kepentingan bersama</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8252', '1806', '<p>Setiap rakyat Indonesia diperlakukan adil dalam semua bidang hukum, ekonomi, sosial, dan kebudayaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8253', '1807', '<p>Tidak memaksakan kehendak kepada orang lain</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8254', '1807', '<p>Suka memberi pertolongan kepada orang lain agar dapat berdiri sendiri</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8255', '1807', '<p>Membeli dan memakai produk lokal</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8256', '1807', '<p>Mengakui persamaan derajat, persamaan hak tanpa membedakan suku agama dan ras</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8257', '1807', '<p>Menghormati dan menghargai hak orang lain</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8258', '1808', '<p>Nasionalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8259', '1808', '<p>Patriotisme</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8260', '1808', '<p>Bela negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8261', '1808', '<p>Revolusiner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8262', '1808', '<p>Primodialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8263', '1809', '<p>Nasionalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8264', '1809', '<p>Patriotisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8265', '1809', '<p>Bela negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8266', '1809', '<p>Revolusiner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8267', '1809', '<p>Primodialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8268', '1810', '<p>Nasionalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8269', '1810', '<p>Patriotisme</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8270', '1810', '<p>Bela negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8271', '1810', '<p>Revolusiner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8272', '1810', '<p>Primodialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8273', '1811', '<p>Nasionalisme</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8274', '1811', '<p>Patriotisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8275', '1811', '<p>Bela negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8276', '1811', '<p>Revolusiner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8277', '1811', '<p>Primodialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8278', '1812', '<p>Nasionalisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8279', '1812', '<p>Patriotisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8280', '1812', '<p>Bela negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8281', '1812', '<p>Revolusiner</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8282', '1812', '<p>Primodialisme</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8283', '1813', '<p>Ketuhanan Yang Maha Esa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8284', '1813', '<p>Kemanusiaan Yang Adil dan Beradap</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8285', '1813', '<p>Persatuan Indonesia</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8286', '1813', '<p>Kerakyatan Yang Dipimpin Oleh Hikmat Kebijaksanaan dalam Permusyawaratan Perwakilan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8287', '1813', '<p>Keadilan Sosial Bagi Seluruh Rakyat Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8288', '1814', '<p>Ketuhanan Yang Maha Esa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8289', '1814', '<p>Kemanusiaan Yang Adil dan Beradap</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8290', '1814', '<p>Persatuan Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8291', '1814', '<p>Kerakyatan Yang Dipimpin Oleh Hikmat Kebijaksanaan dalam Permusyawaratan Perwakilan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8292', '1814', '<p>Keadilan Sosial Bagi Seluruh Rakyat Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8293', '1815', '<p>Ketuhanan Yang Maha Esa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8294', '1815', '<p>Kemanusiaan Yang Adil dan Beradap</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8295', '1815', '<p>Persatuan Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8296', '1815', '<p>Kerakyatan Yang Dipimpin Oleh Hikmat Kebijaksanaan dalam Permusyawaratan Perwakilan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8297', '1815', '<p>Keadilan Sosial Bagi Seluruh Rakyat Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8298', '1816', '<p>Berupaya menegakkan nilai sila ke 1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8299', '1816', '<p>Menegakkan nilai sila ke 3 dan ke 4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8300', '1816', '<p>Berupaya menegakkan nilai sila ke 5 dan ke 4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8301', '1816', '<p>Berupaya menegakkan nilai sila ke 2 dan pokok pikiran ke 4 pembukaan uud 1945</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8302', '1816', '<p>Berupaya menegakkan nilai yang ada pada pokok pikiran ke dua pembukaan UUD 1945 dan sila ke 5</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8303', '1817', '<p>Pancasila sila ke 2</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8304', '1817', '<p>Pancasila sila ke 5 dan 4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8305', '1817', '<p>Pokok pikiran ke 2 UUD 1945 dan sila ke 5</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8306', '1817', '<p>Pokok pikiran ke 4 pembukaan UUD 1945</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8307', '1817', '<p>Semua salah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8308', '1818', '<p>A</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8309', '1818', '<p>B</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8310', '1818', '<p>C</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8311', '1819', '<p>Y</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8312', '1819', '<p>X</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8313', '1819', '<p>Z</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8314', '1820', '<p>45,5 kg</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8315', '1820', '<p>46,5 kg</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8316', '1820', '<p>47,5 kg</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8317', '1820', '<p>48,5 kg</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8318', '1820', '<p>49,5 kg</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8319', '1821', '<p>&ndash; 6</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8320', '1821', '<p>&ndash; 9</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8321', '1821', '<p>&ndash; 10</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8322', '1821', '<p>&ndash; 15</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8323', '1821', '<p>&ndash; 21</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8324', '1822', '<p>&minus; 1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8325', '1822', '<p><img src=\"[base_url]uploads/topik_92/6265fa93ec7e0.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8326', '1822', '<p><img src=\"[base_url]uploads/topik_92/6265faa160a18.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8327', '1822', '<p><img src=\"[base_url]uploads/topik_92/6265fac1c9d48.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8328', '1822', '<p>1</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8329', '1823', '<p><img src=\"[base_url]uploads/topik_92/6265fb56f3b39.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8330', '1823', '<p><img src=\"[base_url]uploads/topik_92/6265fb644194b.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8331', '1823', '<p><img src=\"[base_url]uploads/topik_92/6265fb74a8beb.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8332', '1823', '<p><img src=\"[base_url]uploads/topik_92/6265fb829fa46.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8333', '1823', '<p><img src=\"[base_url]uploads/topik_92/6265fb9133873.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8334', '1824', '<p><img src=\"[base_url]uploads/topik_92/6265fc3ca300a.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8335', '1824', '<p><img src=\"[base_url]uploads/topik_92/6265fc4de8ef0.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8336', '1824', '<p><img src=\"[base_url]uploads/topik_92/6265fc5c89941.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8337', '1824', '<p><img src=\"[base_url]uploads/topik_92/6265fc69eb6b7.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8338', '1824', '<p><img src=\"[base_url]uploads/topik_92/6265fc76e12c7.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8339', '1825', '<p><img src=\"[base_url]uploads/topik_92/6265fd1eea1a6.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8340', '1825', '<p><img src=\"[base_url]uploads/topik_92/6265fd2d94026.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8341', '1825', '<p><img src=\"[base_url]uploads/topik_92/6265fd38ab48e.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8342', '1825', '<p><img src=\"[base_url]uploads/topik_92/6265fd49e52f8.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8343', '1825', '<p><img src=\"[base_url]uploads/topik_92/6265fd5d42492.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8344', '1826', '<p><img src=\"[base_url]uploads/topik_92/6265fe6b40bf2.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8345', '1826', '<p><img src=\"[base_url]uploads/topik_92/6265fe7c487c1.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8346', '1826', '<p><img src=\"[base_url]uploads/topik_92/6265fe8a57c4c.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8347', '1826', '<p><img src=\"[base_url]uploads/topik_92/6265fe9ae1ce1.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8348', '1826', '<p><img src=\"[base_url]uploads/topik_92/6265fea829a0d.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8349', '1827', '<p>2x<sup>2</sup> &minus;3x</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8350', '1827', '<p>2x<sup>2</sup> +5x</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8351', '1827', '<p>2x<sup>2</sup> &minus;11x</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8352', '1827', '<p>2x<sup>2</sup> &minus;11x</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8353', '1827', '<p>2x<sup>2</sup> +11x</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8354', '1828', '<p>x<sup>2</sup> + y<sup>2</sup> + 2x &minus;4y &minus;4 = 0</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8355', '1828', '<p>x<sup>2</sup> + y<sup>2</sup> &minus;2x &minus;8y + 4 = 0</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8356', '1828', '<p>x<sup>2</sup> + y<sup>2</sup> + 2x &minus;8y + 2 = 0</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8357', '1828', '<p>x<sup>2</sup> + y<sup>2</sup> &minus;2x &minus;8y &minus;8 = 0</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8358', '1828', '<p>x<sup>2</sup> + y<sup>2</sup> +2x &minus;8y +8 = 0</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8359', '1829', '<p>52,5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8360', '1829', '<p>57,7</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8361', '1829', '<p>62,5</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8362', '1829', '<p>67,7</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8363', '1829', '<p>72,5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8364', '1830', '<p>2.720 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8365', '1830', '<p>1.200 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8366', '1830', '<p>504 cara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8367', '1830', '<p>360 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8368', '1830', '<p>120 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8369', '1831', '<p>&ndash; 22</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8370', '1831', '<p>&ndash; 20</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8371', '1831', '<p>&ndash; 18</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8372', '1831', '<p>&ndash; 8</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8373', '1831', '<p>&ndash; 4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8374', '1832', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8375', '1832', '<p>8</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8376', '1832', '<p>11</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8377', '1832', '<p>15</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8378', '1832', '<p>21</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8379', '1833', '<p><img src=\"[base_url]uploads/topik_92/6266052c7879e.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8380', '1833', '<p><img src=\"[base_url]uploads/topik_92/6266053b0eeef.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8381', '1833', '<p><img src=\"[base_url]uploads/topik_92/6266054a5688f.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8382', '1833', '<p><img src=\"[base_url]uploads/topik_92/626605575c2a2.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8383', '1833', '<p><img src=\"[base_url]uploads/topik_92/6266056609f6b.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8384', '1834', '<p><img src=\"[base_url]uploads/topik_92/626605a90e703.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8385', '1834', '<p><img src=\"[base_url]uploads/topik_92/626605b9e4b5a.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8386', '1834', '<p><img src=\"[base_url]uploads/topik_92/626605dcaabe7.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8387', '1834', '<p><img src=\"[base_url]uploads/topik_92/626605e970588.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8388', '1834', '<p><img src=\"[base_url]uploads/topik_92/626605f858c66.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8389', '1835', '<p><img src=\"[base_url]uploads/topik_92/626606ca3beb6.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8390', '1835', '<p><img src=\"[base_url]uploads/topik_92/626606d763d73.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8391', '1835', '<p><img src=\"[base_url]uploads/topik_92/626606e390fc9.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8392', '1835', '<p><img src=\"[base_url]uploads/topik_92/626606f0ca1bc.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8393', '1835', '<p><img src=\"[base_url]uploads/topik_92/626606fe15059.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8394', '1836', '<p>126 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8395', '1836', '<p>80 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8396', '1836', '<p>60 cara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8397', '1836', '<p>32 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8398', '1836', '<p>16 cara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8399', '1837', '<p>75</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8400', '1837', '<p>74</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8401', '1837', '<p>70</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8402', '1837', '<p>67</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8403', '1837', '<p>65</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8404', '1838', '<p>-3&lt;<em>x</em>&lt;4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8405', '1838', '<p>-1&lt;<em>x</em>&lt;6</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8406', '1838', '<p><em>x</em>&lt;-3 atau <em>x</em>&gt;4</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8407', '1838', '<p><em>x</em>&lt;-1 atau<em> x</em>&gt;6</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8408', '1838', '<p><em>x</em>&lt;-1 atau <em>x</em>&gt;5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8409', '1839', '<p><img src=\"[base_url]uploads/topik_92/62660a37125f0.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8410', '1839', '<p><img src=\"[base_url]uploads/topik_92/62660a562c13e.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8411', '1839', '<p><img src=\"[base_url]uploads/topik_92/62660a663131d.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8412', '1839', '<p><img src=\"[base_url]uploads/topik_92/62660a72b2357.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8413', '1839', '<p><img src=\"[base_url]uploads/topik_92/62660a7e55126.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8414', '1840', '<p><img src=\"[base_url]uploads/topik_92/62660f7cb92d9.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8415', '1840', '<p><img src=\"[base_url]uploads/topik_92/62660f89e2a40.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8416', '1840', '<p><img src=\"[base_url]uploads/topik_92/62660f96c9b0b.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8417', '1840', '<p><img src=\"[base_url]uploads/topik_92/62660fa5aefd3.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8418', '1840', '<p><img src=\"[base_url]uploads/topik_92/62660fb2ea273.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8419', '1841', '<p><img src=\"[base_url]uploads/topik_92/62660fecb5e40.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8420', '1841', '<p><img src=\"[base_url]uploads/topik_92/62660ffec19c6.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8421', '1841', '<p><img src=\"[base_url]uploads/topik_92/62661011a9ec7.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8422', '1841', '<p><img src=\"[base_url]uploads/topik_92/6266101fbaa98.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8423', '1841', '<p><img src=\"[base_url]uploads/topik_92/626610320fdbc.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8424', '1842', '<p><img src=\"[base_url]uploads/topik_92/626610884587c.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8425', '1842', '<p><img src=\"[base_url]uploads/topik_92/62661095a5bae.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8426', '1842', '<p><img src=\"[base_url]uploads/topik_92/626610a3bb1c7.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8427', '1842', '<p><img src=\"[base_url]uploads/topik_92/6266111268419.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8428', '1842', '<p><img src=\"[base_url]uploads/topik_92/6266111ec0466.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8429', '1843', '<p>sin<sup>2</sup> x</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8430', '1843', '<p>cos<sup>2</sup> x</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8431', '1843', '<p>tan<sup>2</sup> x</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8432', '1843', '<p><em>cos ec<sup>2</sup> x</em></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8433', '1843', '<p>cot<em><sup>2</sup> x</em></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8434', '1844', '<p>Rp6.090.000,00</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8435', '1844', '<p>Rp6.180.000,00</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8436', '1844', '<p>Rp6.360.000,00</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8437', '1844', '<p>Rp6.540.000,00</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8438', '1844', '<p>Rp7.080.000,00</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8439', '1845', '<p>12 meter</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8440', '1845', '<p>12,6 meter</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8441', '1845', '<p>13 meter</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8442', '1845', '<p>13,6 meter</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8443', '1845', '<p>14 meter</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8448', '1846', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8444', '1846', '<p>-6</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8445', '1846', '<p>-5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8446', '1846', '<p>-4</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8447', '1846', '<p>2</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8449', '1847', '<p><img src=\"[base_url]uploads/topik_92/626612deeef00.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8450', '1847', '<p><img src=\"[base_url]uploads/topik_92/626612e9f2b4a.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8451', '1847', '<p><img src=\"[base_url]uploads/topik_92/626612f6acf60.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8452', '1847', '<p><img src=\"[base_url]uploads/topik_92/6266130463213.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8453', '1847', '<p><img src=\"[base_url]uploads/topik_92/626613109bae6.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8454', '1848', '<p>20 bilangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8455', '1848', '<p>30 bilangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8456', '1848', '<p>40 bilangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8457', '1848', '<p>50 bilangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8458', '1848', '<p>80 bilangan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8459', '1849', '<p><img src=\"[base_url]uploads/topik_92/626613617d58c.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8460', '1849', '<p><img src=\"[base_url]uploads/topik_92/6266136ad3d5c.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8461', '1849', '<p><img src=\"[base_url]uploads/topik_92/626613738e857.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8462', '1849', '<p><img src=\"[base_url]uploads/topik_92/6266137e730d7.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8463', '1849', '<p><img src=\"[base_url]uploads/topik_92/62661389f1727.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8464', '1850', '<p>(1) dan (2)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8465', '1850', '<p>(1) dan (3)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8466', '1850', '<p>(2) dan (3)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8467', '1850', '<p>(2) dan (4)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8468', '1850', '<p>(3) dan (4)</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8469', '1851', '<p><img src=\"[base_url]uploads/topik_92/6266140c6c683.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8470', '1851', '<p><img src=\"[base_url]uploads/topik_92/6266141a0ddc9.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8471', '1851', '<p><img src=\"[base_url]uploads/topik_92/62661424e9298.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8472', '1851', '<p><img src=\"[base_url]uploads/topik_92/6266143171d7b.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8473', '1851', '<p><img src=\"[base_url]uploads/topik_92/6266143c2cd7b.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8474', '1852', '<p><img src=\"[base_url]uploads/topik_92/6266146f13b13.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8475', '1852', '<p><img src=\"[base_url]uploads/topik_92/626d456aba96c.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8476', '1852', '<p><img src=\"[base_url]uploads/topik_92/62661488a2668.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8477', '1852', '<p><img src=\"[base_url]uploads/topik_92/6266149434aaf.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8478', '1852', '<p><img src=\"[base_url]uploads/topik_92/6266149fd08ff.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8479', '1853', '<p>2</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8480', '1853', '<p>1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8481', '1853', '<p>0</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8482', '1853', '<p>-1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8483', '1853', '<p>-2</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8484', '1854', '<p>44 orang</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8485', '1854', '<p>88 orang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8486', '1854', '<p>112 orang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8487', '1854', '<p>156 orang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8488', '1854', '<p>224 orang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8489', '1855', '<p><img src=\"[base_url]uploads/topik_92/6266162522747.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8490', '1855', '<p><img src=\"[base_url]uploads/topik_92/62661636053f8.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8491', '1855', '<p><img src=\"[base_url]uploads/topik_92/6266164050d2b.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8492', '1855', '<p><img src=\"[base_url]uploads/topik_92/6266164ae9bb3.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8493', '1855', '<p><img src=\"[base_url]uploads/topik_92/62661658de5b2.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8494', '1856', '<p><img src=\"[base_url]uploads/topik_92/626616a0d10ae.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8495', '1856', '<p><img src=\"[base_url]uploads/topik_92/626d45f68491a.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8496', '1856', '<p><img src=\"[base_url]uploads/topik_92/626616ba07202.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8497', '1856', '<p><img src=\"[base_url]uploads/topik_92/626616c94e5ce.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8498', '1856', '<p><img src=\"[base_url]uploads/topik_92/626616d4abf87.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8499', '1857', '<p>1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8500', '1857', '<p>1,6</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8501', '1857', '<p>2,5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8502', '1857', '<p>2,6</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8503', '1857', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8504', '1858', '<p><img src=\"[base_url]uploads/topik_92/6266176d02401.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8505', '1858', '<p><img src=\"[base_url]uploads/topik_92/626617785e5f7.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8506', '1858', '<p><img src=\"[base_url]uploads/topik_92/62661782844e0.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8507', '1858', '<p><img src=\"[base_url]uploads/topik_92/6266178d9b653.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8508', '1858', '<p><img src=\"[base_url]uploads/topik_92/626617977b33e.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8509', '1859', '<p><img src=\"[base_url]uploads/topik_92/626617b6303dd.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8510', '1859', '<p><img src=\"[base_url]uploads/topik_92/626617beca65e.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8511', '1859', '<p><img src=\"[base_url]uploads/topik_92/626617cb2777f.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8512', '1859', '<p><img src=\"[base_url]uploads/topik_92/626617d50c71c.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8513', '1859', '<p><img src=\"[base_url]uploads/topik_92/626617dea4f94.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8514', '1860', '<p>Sulawesi Utara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8515', '1860', '<p>Sulawesi Selatan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8517', '1860', '<p>Sumatera Selatan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8518', '1860', '<p>NTT</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8519', '1861', '<p>PERBASI</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8520', '1861', '<p>PTMSI</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8521', '1861', '<p>PBSI</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8522', '1861', '<p>PBTSI</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8524', '1862', '<p>Sinovac&nbsp;</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8525', '1862', '<p>Pfizer</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8526', '1862', '<p>Astrazeneca</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8528', '1862', '<p>Novavax</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8529', '1863', '<p>Spanyol</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8530', '1863', '<p>Meksiko</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8531', '1863', '<p>Argentina</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8532', '1863', '<p>Prancis</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8534', '1864', '<p>Berarti manusia sebagai makhluk tertinggi yang secara moral memiliki kesempurnaan dan bersih dari cela</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8535', '1864', '<p>Berarti Kepolisian Negara Republik Indonesia yang bertugas mengawal dan mengamankan masyarakat, bangsa dan negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8536', '1864', '<p>Berarti setiap anggota Kepolisian Negara Republik Indonesia (yang juga disebut sebagai Bhayangkari) yang secara ikhlas mengawal dan mengamankan negara serta rela berkorban demi mengabdi kepentingan masyarakat dan bangsa seumur hidupnya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8537', '1864', '<p>Berarti kelompok masyarakat yang tinggal di suatu wilayah tertentu yang memiliki kedaulatan ke dalam dan ke luar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8538', '1865', '<p>Mapolres</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8539', '1865', '<p>Mapolsek</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8540', '1865', '<p>Mapolresta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8541', '1865', '<p>Mapolda</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8542', '1866', '<p>AIPDA</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8543', '1866', '<p>AIPTU</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8544', '1866', '<p>IPDA</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8545', '1866', '<p>IPTU</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8546', '1867', '<p>Pegawai negeri pada Kepolisian Negara Republik Indonesia</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8547', '1867', '<p>Warga Negara Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8548', '1867', '<p>WNA yang menjadi WNI</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8549', '1867', '<p>Pegawai Negeri Sipil</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8550', '1868', '<p>Kepentingan Umum</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8551', '1868', '<p>Keamanan dan Ketertiban Masyarakat</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8552', '1868', '<p>Peraturan Kepolisian</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8553', '1868', '<p>Kepentingan Pribadi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8554', '1869', '<p>Kapolsek</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8555', '1869', '<p>Kapolda</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8556', '1869', '<p>Kapolresta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8557', '1869', '<p>Kapolri</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8558', '1870', '<p>Dewan Perwakilan Rakyat</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8559', '1870', '<p>Majelis Permusyawaratan Rakyat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8560', '1870', '<p>Mahkamah Agung</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8561', '1870', '<p>Wakil Presiden</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8562', '1871', '<p>Jenjang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8563', '1871', '<p>kepangkatan dan karier</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8564', '1871', '<p>karier</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8565', '1871', '<p>semua benar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8566', '1872', '<p>Tugas pokok Kepolisian Negara Republik Indonesia, kecuali &hellip;.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8567', '1872', '<p>menegakkan hukum</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8568', '1872', '<p>memberikan perlindungan, pengayoman, dan pelayanan kepada masyarakat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8569', '1872', '<p>membawa dan menghadapkan orang kepada penyidik dalam rangka penyidikan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8570', '1873', '<p>55 tahun</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8571', '1873', '<p>56 tahun</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8572', '1873', '<p>58 tahun</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8573', '1873', '<p>60 tahun</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8574', '1874', '<p>Laksamana TNI (Purn.) Luhut Binsar panjaitan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8575', '1874', '<p>Jenderal TNI (Purn.) Wiranto</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8576', '1874', '<p>Yasonna Laoly</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8577', '1874', '<p>Prof. Dr. Mohammad Mahfud MD, S.H., S.U., M.I.P.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8578', '1875', '<p>SESPIMPOL</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8579', '1875', '<p>SETUKPA</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8580', '1875', '<p>STIK</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8581', '1875', '<p>AKPOL</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8582', '1876', '<p>Brata Pertama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8583', '1876', '<p>Brata Kedua</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8584', '1876', '<p>Brata Ketiga</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8585', '1876', '<p>TRIBRATA</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8586', '1877', '<p>Meniadakan segala bentuk gangguan keamanan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8587', '1877', '<p>Bahwa kita anggota Polri secara umum tugasnya adalah sebagai Pelindung dan Pelayan masyarakat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8588', '1877', '<p>Kita anggota Polri harus mempertanggungjawabkan pelaksanaan tugas kita kepada masyarakat, bangsa dan negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8589', '1877', '<p>Kita polisi Indonesia adalah Polisi bangsa Indonesia, Polisi negara Indonesia dan bukan sebagai alat politik atau alat pemerintah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8590', '1878', '<p>segala hal-ihwal yang berkaitan dengan fungsi dan lembaga polisi sesuai dengan peraturan perundang-undangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8591', '1878', '<p>pegawai negeri pada Kepolisian Negara Republik Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8592', '1878', '<p>anggota Kepolisian Negara Republik Indonesia yang berdasarkan undang-undang memiliki wewenang umum Kepolisian</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8593', '1878', '<p>pejabat Kepolisian Negara Republik Indonesia yang diberi wewenang oleh undang-undang untuk melakukan penyelidikan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8594', '1879', '<p>Susilo Bambang Yudhoyono</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8595', '1879', '<p>Megawati Soekarnoputri</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8596', '1879', '<p>Abdurrahman wahid</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8597', '1879', '<p>BJ Habibie</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8598', '1880', '<p>Brigjen Pol Drs. Nandang Djumantara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8599', '1880', '<p>Komisaris Besar Polisi Drs.Rikwanto</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8600', '1880', '<p>Jenderal Pol. Drs. Listyo Sigit Prabowo, M.Si.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8601', '1880', '<p>Jendral Polisi Tito Karnavian.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8602', '1881', '<p>catur prasetya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8603', '1881', '<p>Tribrata</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8604', '1881', '<p>Sumpah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8605', '1881', '<p>Janji</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8606', '1882', '<p>Yang bersangkutan memenuhi syarat menjadi calon anggota Polisi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8607', '1882', '<p>Yang bersangkutan dihukum karena melanggar UU</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8608', '1882', '<p>Yang bersangkutan tidak memenuhi syarat menjadi anggota Polri</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8609', '1882', '<p>Yang bersangkutan diberikan penghargaan untuk dapat menjadi anggota Polri</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8610', '1883', '<p>BRIPDA, BRIPKA, BRIGPOL, BRIPTU</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8611', '1883', '<p>BRIPDA, BRIPTU, BRIGPOL, BRIPKA</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8612', '1883', '<p>BRIPTU, BRIPDA, BRIGPOL, BRIPKA</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8613', '1883', '<p>BRIPTU, BRIPDA, BRIPKA, BRIGPOL</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8614', '1884', '<p>KombesPol Drs.Rikwanto, SH. M.Hum</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8615', '1884', '<p>Komjen Gatot Eddy Pramono</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8616', '1884', '<p>Brigjen Boy Rafli Amar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8617', '1884', '<p>Komjen Badrodin Haiti</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8618', '1885', '<p>Polri dapat melakukan diskresi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8619', '1885', '<p>Adanya Lembaga Kepolisian Nasional</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8620', '1885', '<p>Anggota Polri dalam menjalankan tugasnya dapat melakukan tindakan lain</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8621', '1885', '<p>Polri merupakan organisasi sipil yang berbentuk komando</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8622', '1886', '<p>Presiden</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8623', '1886', '<p>DPR</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8624', '1886', '<p>MA</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8625', '1886', '<p>Kapolri</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8626', '1887', '<p>WNI</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8627', '1887', '<p>Berpendidikan minimal SMA atau sederajat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8628', '1887', '<p>Berumur minimal 18 (delapan belas) tahun</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8629', '1887', '<p>Pernah melakukan tindakana pidana</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8630', '1888', '<p>Undang-undang Nomor 2 Tahun 2002</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8631', '1888', '<p>Peraturan Pemerintah Pengganti Undang-undang Nomor 2 Tahun 2002</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8632', '1888', '<p>Peraturan Pemerintah Nomor 1 Tahun 2009</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8633', '1888', '<p>Keputusan Presiden Nomor 54 Tahun 1987</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8634', '1889', '<p>Tribrata</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8635', '1889', '<p>Catur Prasetya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8636', '1889', '<p>Rasta Sewakottama</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8637', '1889', '<p>Sewakottama Rasta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8638', '1890', '<p>Pengayom masyarakat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8639', '1890', '<p>Pelindung rakyat dan Negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8640', '1890', '<p>Pelindung masyarakat dan bangsa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8641', '1890', '<p>Pengayom rakyat dan negara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8642', '1891', '<p>Gabungan provinsi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8643', '1891', '<p>Kabupaten</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8644', '1891', '<p>Kota</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8645', '1891', '<p>Provinsi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8646', '1892', '<p>Direktur Akpol</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8647', '1892', '<p>Ketua Akpol</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8648', '1892', '<p>Kepala Akpol</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8649', '1892', '<p>Gubernur Akpol</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8650', '1893', '<p>Pasukan tempur</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8651', '1893', '<p>Pasukan pengaman</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8652', '1893', '<p>Pasukan bersenjata</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8653', '1893', '<p>tentara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8654', '1894', '<p>Jenderal (Pol) R.Soetjipto Joedihardjo</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8655', '1894', '<p>Jenderal (Pol) R.Soekarno Djojonagoro</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8656', '1894', '<p>Jenderal (Pol) R.S.Soekanto Tjokrodiatmodjo</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8657', '1894', '<p>Jenderal (Pol) R.Soetjipto Danoekoesomo</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8658', '1895', '<p>Bhayangkara Polisi Satu (Bharatu)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8659', '1895', '<p>Bhayangkara Polisi Dua (Bharada)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8660', '1895', '<p>Inspektur Polisi Dua (Ipda)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8661', '1895', '<p>Ajun Brigadir Polisi Dua (Abripda)</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8662', '1896', '<p>Memelihara keamanan dan ketertiban masyarakat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8663', '1896', '<p>Menegakkan hukum</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8664', '1896', '<p>Membantu menanggulangi akibat bencana alam, pengungsian, dan pemberian bantuan kemanusiaan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8665', '1896', '<p>Menjaga keselamatan jiwa raga, harta benda, dan hak asasi manusia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8666', '1897', '<p>Kebangsaan Indonesia, internasionalisme (perikemanusiaan), mufakat, kesejahteraan social, dan ketuhanan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8667', '1897', '<p>Gotong royong, ketuhanan, kerakyatan, nasionalisme, dan demokrasi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8668', '1897', '<p>Interasionalisme, nasionalisme, mufakat, demokrasi, dan kesejahteraan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8669', '1897', '<p>Kesejahteraan social, internasional, nasionalisme, perikemanusiaan, dan ketuhanan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8670', '1898', '<p>Singapura, Brunei Darussalam, Filipina, Samudera Pasifik, dan Laut Cina Selatan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8671', '1898', '<p>Australia, Timor Leste, dan Samudera Hindia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8672', '1898', '<p>Papua Nugini, Timor Leste, dan Samudera Pasifik</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8673', '1898', '<p>India, Benua Asia, dan Samudera Hindia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8674', '1899', '<p>Kepolisian Negara RI yang bertugas mengawal dan mengamankan masyarakat.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8675', '1899', '<p>Wujud sikap morl tertinggi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8676', '1899', '<p>Manusia sebagai makhluk tertinggi yang secara moral memiliki kesempurnaan dan bersih dari cela.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8677', '1899', '<p>Tindakan untuk membuat sesuatu menjadi tidak ada.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8678', '1900', '<p>Tiga jalan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8679', '1900', '<p>Tiga kaul</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8680', '1900', '<p>Tiga Azas Kewajiban</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8681', '1900', '<p>Tiga jalan kehidupan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8682', '1901', '<p>Sofyan djalil<br />
&nbsp;</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8683', '1901', '<p>Rahmat gobel</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8684', '1901', '<p>Amran sulaiman</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8685', '1901', '<p>Praktikno</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8686', '1902', '<p>Hanif dakhiri</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8687', '1902', '<p>Ferry mursyidan Baldan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8688', '1902', '<p>Fachrul Rozi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8689', '1902', '<p>Lukman hakim saifudun</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8690', '1903', '<p>Menteri tenaga kerja</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8691', '1903', '<p>Menteri riset teknologi dan pendidikan tinggi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8692', '1903', '<p>Menteri pemuda dan olahraga</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8693', '1903', '<p>Menteri kesehatan.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8694', '1904', '<p>1945</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8695', '1904', '<p>1963</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8696', '1904', '<p>1982</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8697', '1904', '<p>2003</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8698', '1905', '<p>KRI Matjan Tutul</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8699', '1905', '<p>KRI Matjan Kumbang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8700', '1905', '<p>KRI Jaguar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8701', '1905', '<p>KRI Neptune</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8704', '1906', '<p>1820 - 1830</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8705', '1906', '<p>1930 - 1945</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8702', '1906', '<p>1825 - 1830</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8703', '1906', '<p>1985 - 1990</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8706', '1907', '<p>1959</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8707', '1907', '<p>1960</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8708', '1907', '<p>1961</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8709', '1907', '<p>1962</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8710', '1908', '<p>Banjarmasin</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8711', '1908', '<p>Buton</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8712', '1908', '<p>Kendari</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8713', '1908', '<p>Makasar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8714', '1909', '<p>Umar Wirahadikusumah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8715', '1909', '<p>Soedharmono</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8716', '1909', '<p>B.J Habibie</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8717', '1909', '<p>Tri Sutrisno</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8718', '1910', '<p>A unique entertainment</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8719', '1910', '<p>A grappling python</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8720', '1910', '<p>A music dance</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8721', '1910', '<p>A poolside</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8722', '1910', '<p>Crocodile</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8723', '1911', '<p>3.00 a.m.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8724', '1911', '<p>3.30. p.m.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8725', '1911', '<p style=\"text-align:justify\">4.00. a.m.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8726', '1911', '<p>4.00. p.m.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8727', '1911', '<p>4.30. p.m.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8728', '1912', '<p>The beautiful tiger moths</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8729', '1912', '<p>The attractive garden tiger moths.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8730', '1912', '<p>The least suitable creatures to eat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8731', '1912', '<p>Unpleasant tasks and smells of moths</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8732', '1912', '<p>Creatures with the brightest coloration</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8733', '1913', '<p>Appropriate</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8734', '1913', '<p>Delicate</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8735', '1913', '<p>Elegant</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8736', '1913', '<p>Light</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8737', '1913', '<p>Mild</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8738', '1914', '<p>The striking coloration of the garden tiger moth which is attractive but is also poisonous.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8739', '1914', '<p>The Creatures with the brightest coloration</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8740', '1914', '<p>Certain glands in the garden tiger moth produce strong toxins that circulate throughout the insect&rsquo;s bloodstream</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8741', '1914', '<p>Other glands secrete bubbles that produce a noxious warning smell.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8742', '1914', '<p>The tiger moth, indeed, is a clear example of a concept that many predators intuitively understand</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8743', '1915', '<p>To inform the reader about tiger moth in general</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8744', '1915', '<p>To retell the creatures with the brightest color</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8745', '1915', '<p>To explain how to breed the garden moth</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8746', '1915', '<p>To analyze the garden tiger moth</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8747', '1915', '<p>To describe the garden tiger moth in detail</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8748', '1916', '<p>Dangerous</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8749', '1916', '<p>Loose</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8750', '1916', '<p>Wounded</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8751', '1916', '<p>Decease</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8752', '1916', '<p>Dying</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8753', '1917', '<p>To explain how there are too many accidents</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8754', '1917', '<p>To explain how there are too many accidents</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8755', '1917', '<p>To inform about road accidents</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8756', '1917', '<p>To describe the road accidents</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8757', '1917', '<p>To retell the news about accidents</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8758', '1918', '<p>Blame the drivers</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8759', '1918', '<p>Ignore the traffic rules</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8760', '1918', '<p>Drink too much alcohol</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8761', '1918', '<p>Walk on the pavement</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8762', '1918', '<p>Walk too slow</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8763', '1919', '<p>Because his appearance looks like Butet, the famous comedian</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8764', '1919', '<p>Because he likes to make jokes</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8765', '1919', '<p>Because he likes to imitate many sounds, like Butet</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8766', '1919', '<p>Because he is Butet&rsquo;s son</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8767', '1919', '<p>Because he is interesting in comedy</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8768', '1920', '<p>The sound of broken window</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8769', '1920', '<p>The sound of squeaky animal</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8770', '1920', '<p>The sound of art&rsquo;s teacher voice</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8771', '1920', '<p>The sound of chalk squeaking on the blackboard</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8772', '1920', '<p>The sound of screaming woman</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8773', '1921', '<p>Butet&rsquo;s habit</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8774', '1921', '<p>The way how Ghanie always imitate many sounds</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8775', '1921', '<p>The description of the writer&rsquo;s friend, Ghanie</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8776', '1921', '<p>The appearance of Butet, the famous comedian</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8777', '1921', '<p>The description of the writer&rsquo;s school life</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8778', '1922', '<p>The movie introduces the determined teacher of Belitong</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8779', '1922', '<p>The movie is much better than his original writing</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8780', '1922', '<p>The movie was directed by a woman director</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8781', '1922', '<p>Mira Lesmana is a well known producer</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8782', '1922', '<p>The movie is starred by a famous actress</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8783', '1923', '<p>It was played by Hollywood stars</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8784', '1923', '<p>Its book was very popuar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8785', '1923', '<p>It was adapted from a novel</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8786', '1923', '<p>It focused on social and educational isuess</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8787', '1923', '<p>It was starred by well-known actors and actresses</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8788', '1924', '<p>Disappointing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8789', '1924', '<p>Unsatisfying</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8790', '1924', '<p>Astonishing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8791', '1924', '<p>Revealing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8792', '1924', '<p>Inspiring</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8793', '1925', '<p>Reducing stress, effort and time with working at home</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8794', '1925', '<p>The advantages and disadvantages of home office</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8795', '1925', '<p>Some disadvantages of making home as an office</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8796', '1925', '<p>Some advantages of making home as an office</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8797', '1925', '<p>The benefit of having an office at home</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8798', '1926', '<p>Keeping the schedule is hard</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8799', '1926', '<p>Having a home office will save money</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8800', '1926', '<p>Having an home office can get us closer to our family</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8801', '1926', '<p>Working at home can reduce stress, effort, and save time</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8802', '1926', '<p>Having a home office, we are free to set the work schedule</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8803', '1927', '<p>They can get close to their family</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8804', '1927', '<p>They can develop their business easily</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8805', '1927', '<p>They do not need to leave their house</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8806', '1927', '<p>They can stay at any parts of their house</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8807', '1927', '<p>They might enjoy their business with their family</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8808', '1928', '<p>Lost</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8809', '1928', '<p>Profit</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8810', '1928', '<p>Purchase</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8811', '1928', '<p>Sold</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8812', '1928', '<p>Advantage</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8813', '1929', '<p>The office</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8814', '1929', '<p>Some people</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8815', '1929', '<p>An office at home</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8816', '1929', '<p>Agreement</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8817', '1929', '<p>An building of office</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8818', '1930', '<p>Camera</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8819', '1930', '<p>Photo album</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8820', '1930', '<p>Photographers</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8821', '1930', '<p>Color photograph</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8822', '1930', '<p>Photographic equipment</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8823', '1931', '<p>Camera</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8824', '1931', '<p>Handsome album</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8825', '1931', '<p>Free gift</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8826', '1931', '<p>DIANA Photography</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8827', '1931', '<p>Memories</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8828', '1932', '<p>Photo album at special prices</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8829', '1932', '<p>Photos of different objects</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8830', '1932', '<p>Photographic equipment</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8831', '1932', '<p>Printed t &ndash; shirts</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8832', '1932', '<p>Good cameras</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8833', '1933', '<p>New pictures</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8834', '1933', '<p>Old pictures</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8835', '1933', '<p>Odd pictures</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8836', '1933', '<p>Quick pictures</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8837', '1933', '<p>Strange pictures</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8838', '1934', '<p>Reasons for printed advertisement</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8839', '1934', '<p>Strong views on printed advertisement</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8840', '1934', '<p>Advertisement considered as a junk mail</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8841', '1934', '<p>Advertisement as an important source of information</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8842', '1934', '<p>Whether printed advertisement is important or not</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8843', '1935', '<p>It is easier to find advertisement in a newspaper</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8844', '1935', '<p>It can give information what is on sale</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8845', '1935', '<p>It can influence people to buy things</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8846', '1935', '<p>It might cost a lot of money</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8847', '1935', '<p>It is an interesting issue</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8848', '1936', '<p>Ads are only junk mail</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8849', '1936', '<p>Ads cost a lot of money</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8850', '1936', '<p>Ads make things more expensive</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8851', '1936', '<p>Ads make people buy things they don&rsquo;t need</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8852', '1936', '<p>Ads help consumers to know what things are on sale</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8853', '1937', '<p>Let</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8854', '1937', '<p>Have</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8855', '1937', '<p>Make</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8856', '1937', '<p>Affect</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8857', '1937', '<p>Improve</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8858', '1938', '<p>The location of TMII</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8859', '1938', '<p>The description of TMII</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8860', '1938', '<p>The history of TMII</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8861', '1938', '<p>The benefit of TMII</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8862', '1938', '<p>A tourist destination</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8863', '1939', '<p>They are put in a theatre</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8864', '1939', '<p>They are shown by a cable car</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8865', '1939', '<p>They are placed in separated pavilions</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8866', '1939', '<p>They are represented in the forms of dances</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8867', '1939', '<p>They are positioned in the middle of the park</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8868', '1940', '<p>Discussion</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8869', '1940', '<p>Report</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8870', '1940', '<p>Recount</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8871', '1940', '<p>Explanation</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8872', '1940', '<p>Description</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8873', '1941', '<p>The park</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8874', '1941', '<p>TMII</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8875', '1941', '<p>The virtually</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8876', '1941', '<p>The architecture</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8877', '1941', '<p>The dances</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8878', '1942', '<p>Closing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8879', '1942', '<p>Summarize</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8880', '1942', '<p>Completing</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8881', '1942', '<p>Called</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8882', '1942', '<p>Distribute</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8883', '1943', '<p>To describe the step to make a chocolate</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8884', '1943', '<p>To present two point of view about chocolate</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8885', '1943', '<p>To give information about chocolate</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8886', '1943', '<p>To explain the process of making chocolate</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8887', '1943', '<p>To amuse the readers</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8888', '1944', '<p>the process of producing chocolate</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8889', '1944', '<p>how to produce the cocoa flavor</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8890', '1944', '<p>where chocolate comes from</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8891', '1944', '<p>the chocolate liquor</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8892', '1944', '<p>the cacao fruit</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8893', '1945', '<p>Arranged</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8894', '1945', '<p>Combined</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8895', '1945', '<p>Separated</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8896', '1945', '<p>Distributed</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8897', '1945', '<p>Organized</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8898', '1946', '<p>By fermenting the beans</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8899', '1946', '<p>By roasting the beans</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8900', '1946', '<p>By blending the beans</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8901', '1946', '<p>By sorting the beans</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8902', '1946', '<p>By drying the beans</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8903', '1947', '<p>After the cacao is processed into the cocoa beans, the beans are baked and ground into the chocolate liquor</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8904', '1947', '<p>After the cocoa is processed into nibs, the blended nibs are ground to produce chocolate liquor</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8905', '1947', '<p>After the cocoa beans are fermented in dried sun, they are produced into chocolate liquor</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8906', '1947', '<p>After the cacao is dried in the sun, the cacao is processed into chocolate liquor</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8907', '1947', '<p>The cacao can be directly processed into chocolate liquor</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8908', '1948', '<p>Identified</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8909', '1948', '<p>Accepted</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8910', '1948', '<p>Noticed</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8911', '1948', '<p>Recalled</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8912', '1948', '<p>Detected</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8913', '1949', '<p>12</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8914', '1949', '<p>28</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8915', '1949', '<p>13</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8916', '1949', '<p>5</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8917', '1949', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8918', '1950', '<p>To explain about how Palestine recognize as a new country.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8919', '1950', '<p>To retell the past experience about Palestine.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8920', '1950', '<p>To give information about newsworthy items about Palestine</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8921', '1950', '<p>To informs about Palestine war</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8922', '1950', '<p>To persuade the readers to recognize Palestine</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8923', '1951', '<p>Europe</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8924', '1951', '<p>Palestine</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8925', '1951', '<p>Iceland</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8926', '1951', '<p>Peru</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8927', '1951', '<p>Syria</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8928', '1952', '<p>The two men have captivated the audience in the first film</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8929', '1952', '<p>The chemistry is formed through their friendship in real life</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8930', '1952', '<p>The two men are partner in investigating some cases</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8931', '1952', '<p>The two men describe the mind wander</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8932', '1952', '<p>The two men were sibling</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8933', '1953', '<p>He hired the clowns</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8934', '1953', '<p>He showed the cartoons</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8935', '1953', '<p>He acted like comedians</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8936', '1953', '<p>He made jokes within the scene</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8937', '1953', '<p>He forced the actors to be funny</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8938', '1954', '<p>The chess competition showed mind wanders</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8939', '1954', '<p>The visual effect on the movie is testable</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8940', '1954', '<p>The movie is terribly out of standard</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8941', '1954', '<p>The actors did not perform well</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8942', '1954', '<p>The movie is worth watching</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8943', '1955', '<p>The synopsis of the movie</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8944', '1955', '<p>The compliment of the movie</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8945', '1955', '<p>The critique of the movie</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8946', '1955', '<p>The plot of the movie</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8947', '1955', '<p>The dialogue of the movie</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8948', '1956', '<p>were</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8949', '1956', '<p>was</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8950', '1956', '<p>is</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8951', '1956', '<p>Am</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8952', '1956', '<p>Are</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8953', '1957', '<p>Made</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8954', '1957', '<p>Spent</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8955', '1957', '<p>Gave</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8956', '1957', '<p>Went</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8957', '1957', '<p>Saw</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8960', '1958', '<p>Darkly</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8961', '1958', '<p>Nicely</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8962', '1958', '<p>Brightly</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8958', '1958', '<p>Beautifully</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8959', '1958', '<p>Clearly</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8963', '1959', '<p>Shine</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8964', '1959', '<p>Come</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8965', '1959', '<p>Flow</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8966', '1959', '<p>Fly</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8967', '1959', '<p>Blow</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8968', '1960', '<p>Batang pohon mahoni yang besar menyangkut di kaki jembatan desa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8969', '1960', '<p>Musim penghujan datang tiga bulan lebih cepat dari waktu biasanya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8970', '1960', '<p>Tiang pancang jembatan yang miring karena pemasangan kurang tepat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8971', '1960', '<p>Rekomendasi rencana pembangunan oleh perancang tidak terlaksana</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8972', '1960', '<p>Air bah menenggelamkan jembatan sebagai akses alan penduduk desa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8973', '1961', '<p>Ramah, baik, perhatian, dan bertanggung jawab</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8974', '1961', '<p>Teguh, tabah, ramah, cerewet, dan peduli</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8975', '1961', '<p>Bahagia, senang, ceria, peduli, dan teguh</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8976', '1961', '<p>Periang, pemalu,pemalas, dan cerewet</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8977', '1961', '<p>Teguh, kuat, baik, peduli, dan menyenangkan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8978', '1962', '<p>1, 2, dan 3</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8979', '1962', '<p>1, 3, dan 4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8980', '1962', '<p>2, 3, dan 4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8981', '1962', '<p>2, 3, dan 5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8982', '1962', '<p>3, 4, dan 5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8983', '1963', '<p>(1), (2), dan (3)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8984', '1963', '<p>(1), (3), dan (5)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8985', '1963', '<p>(1), (2), dan (5)</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8986', '1963', '<p>(2), (3), dan (4)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8987', '1963', '<p>(3), (4), dan (5)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8988', '1964', '<p>Anak yang sangat saying kepada ayahnya.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8989', '1964', '<p>Kakak beradik yang bertengkar dan dilerai ayahnya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8990', '1964', '<p>Perasaan seroang ayah untuk melepas anak-anaknya.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8991', '1964', '<p>Kegelisahan anak untuk meninggalkan ayahnya.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8992', '1964', '<p>Ayah yang akan pergi meninggalkan anak-anaknya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8993', '1965', '<p>Sudut pandang orang pertama pelaku utama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8994', '1965', '<p>Sudut pandang orang pertama serba tahu</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8995', '1965', '<p>Sudut pandang orang pertama pelaku sampingan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8996', '1965', '<p>Sudut pandang orang ketiga serba tahu</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8997', '1965', '<p>Sudut pandang orang ketiga terbatas</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8998', '1966', '<p>Ibu yang selalu mengampuni kesalahan anaknya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('8999', '1966', '<p>Ibu yang selalu menyayangi anaknya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9000', '1966', '<p>Anak yang tidak bersikap santun kepada ibunya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9001', '1966', '<p>Sayangilah dan bersikap santun kepada orang tua</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9002', '1966', '<p>Tegaslah kepada siapa saja</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9003', '1967', '<p>moral</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9004', '1967', '<p>sosial</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9005', '1967', '<p>budaya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9006', '1967', '<p>ekonomi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9007', '1967', '<p>pendidikan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9008', '1968', '<p>seorang ibu banyak berbuat salah pada anaknya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9009', '1968', '<p>seorang ibu selalu didurhakai anaknya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9010', '1968', '<p>seorang ibu selalu membimbing anaknya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9011', '1968', '<p>seorang ibu mengampuni kesalahan anaknya</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9012', '1968', '<p>seorang ibu selalu menyayangi anaknya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9013', '1969', '<p>bekerja untuk keluarga</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9014', '1969', '<p>sabar dalam bertindak</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9015', '1969', '<p>berusaha menepati janji</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9016', '1969', '<p>setia kepada pasangan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9017', '1969', '<p>tabah menghadapi masalah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9018', '1970', '<p>Jalan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9019', '1970', '<p>Halaman rumah</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9020', '1970', '<p>Lapangan desa</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9021', '1970', '<p>Di proyek pembangunan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9022', '1970', '<p>Kamar depan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9023', '1971', '<p>Paragraf ke-1 kalimat ke-4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9024', '1971', '<p>Paragraf ke-2 kalimat ke-3<br />
Paragraf ke-1 kalimat ke-5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9025', '1971', '<p>Paragraf ke-2 kalimat ke-4<br />
Paragraf ke-1 kalimat ke-1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9026', '1971', '<p>Paragraf ke-2 kalimat ke-1<br />
Paragraf ke-1 kalimat ke-1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9027', '1971', '<p>Paragraf ke-2 kalimat ke-2<br />
Paragraf ke-1 kalimat ke-1<br />
Paragraf ke-2 kalimat ke-4</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9028', '1972', '<p>secara analitik</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9029', '1972', '<p>secara dramatik melalui penggambaran latar tokoh</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9030', '1972', '<p>secara dramatik melalui penggambaran fisik tokoh</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9031', '1972', '<p>secara dramatik melalui penggambaran lingkungan sekitar tokoh</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9032', '1972', '<p>secara dramatik melalui cara berbicara tokoh</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9033', '1973', '<p>Personifikasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9034', '1973', '<p>Metafora</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9035', '1973', '<p>Hiperbola</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9036', '1973', '<p>Asosiasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9037', '1973', '<p>Alegori</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9038', '1974', '<p>kepala batu</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9039', '1974', '<p>kepala udang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9040', '1974', '<p>kepala dingin</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9041', '1974', '<p>kepala berat</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9042', '1974', '<p>kepala angin</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9043', '1975', '<p>(1)-(5)-(2)-(6)-(3)-(4)</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9044', '1975', '<p>(1)-(2)-(3)-(4)-(5)-(6)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9045', '1975', '<p>(2)-(4)-(6)-(5)-(1)-(3)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9046', '1975', '<p>(5)-(2)-(6)-(1)-(3)-(4)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9047', '1975', '<p>(2)-(5)-(6)-(3)-(1)-(4)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9048', '1976', '<p>Orang Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9049', '1976', '<p>Umat beragama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9050', '1976', '<p>Pemimpin agama</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9051', '1976', '<p>Orang baik</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9052', '1976', '<p>Orang beriman</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9053', '1977', '<p>Menghidupi persaudaraan antarumat beriman di mana pun</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9054', '1977', '<p>Semangat persaudaraan mengalir ke segala penjuru</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9055', '1977', '<p>Membangun relasi saling menghormati antarpemimpin umat beragama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9056', '1977', '<p>Iman tanpa perbuatan pada hakikatnya adalah mati</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9057', '1977', '<p>Saling menghormati antarpemeluk agama yang sama atau pun berbeda</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9058', '1978', '<p>(1) dan (2)</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9059', '1978', '<p>(1) dan (3)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9060', '1978', '<p>(1) dan (5)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9061', '1978', '<p>(2) dan (6)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9062', '1978', '<p>(6) dan (7)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9063', '1979', '<p>Indonesia menunggu 19 tahun untuk mendapatkan piala</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9064', '1979', '<p>Indonesia berhasil mendapatkan piala Thomas</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9065', '1979', '<p>Cabang olahraga bulu tangkis Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9066', '1979', '<p>Sanksi untuk Indonesia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9067', '1979', '<p>Bendera merah putih tidak diizinkan berkibar di podium</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9068', '1980', '<p>Orang yang berjasa bagi suatu kelompok</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9069', '1980', '<p>Orang yang terpilih dalam pemilihan umum</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9070', '1980', '<p>Orang yang diharapkan akan memegang peran yang penting</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9071', '1980', '<p>Orang yang dipercaya mampu memimpin suatu kegiatan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9072', '1980', '<p>Orang yang setia dengan kelompok organisasinya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9073', '1981', '<p>Gerakan bersama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9074', '1981', '<p>Pembentukan kader remaja di sekolah</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9075', '1981', '<p>Mengingatkan sesama teman</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9076', '1981', '<p>Pola asupan yang benar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9077', '1981', '<p>Langkah bijak pemerintah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9078', '1982', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9079', '1982', '<p>4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9080', '1982', '<p>5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9081', '1982', '<p>6</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9082', '1982', '<p>7</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9083', '1983', '<p>1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9084', '1983', '<p>2</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9085', '1983', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9086', '1983', '<p>4</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9087', '1983', '<p>5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9088', '1984', '<p>1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9089', '1984', '<p>2</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9090', '1984', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9091', '1984', '<p>4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9092', '1984', '<p>5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9093', '1985', '<p>Pengenalan Isu- Penyampaian Pendapat</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9094', '1985', '<p>Orientasi &ndash; Pemunculan masalah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9095', '1985', '<p>Pengenalan Isu- Penegasan Ulang</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9096', '1985', '<p>Penyampaian Pendapat &ndash; Reorientasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9097', '1985', '<p>Pembuka &ndash; Inti</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9098', '1986', '<p>(1), (2), dan (3)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9099', '1986', '<p>(1), (3), dan (5)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9100', '1986', '<p>(1), (4), dan (5)</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9101', '1986', '<p>(2), (3), dan (4)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9102', '1986', '<p>(2), (4), dan (5)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9103', '1987', '<p>mengusir, meminjam, marah</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9104', '1987', '<p>dicangkul, mengusir, kekayaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9105', '1987', '<p>kaget, sebesar, pergi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9106', '1987', '<p>berkata, menunjukkan, bongkahan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9107', '1987', '<p>mudah, meminjam, cangkul</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9108', '1988', '<p>1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9109', '1988', '<p>2</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9110', '1988', '<p>3</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9111', '1988', '<p>4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9112', '1988', '<p>5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9113', '1989', '<p>Colombo Plan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9114', '1989', '<p>antar negara</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9115', '1989', '<p>di Asia</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9116', '1989', '<p>Asia Tenggara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9117', '1989', '<p>The Asia Union di Baguio, Filipina</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9118', '1990', '<p><strong>Akan tetapi</strong>, keanggotaannya tidak berasal dari suatu kawasan tertentu.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9119', '1990', '<p>&hellip; keanggotaannya tidak berasal dari suatu kawasan tertentu dan operasinya bersifat bilatelaral.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9120', '1990', '<p>&hellip; operasinya bersifat bilatelaral,&nbsp;<strong>sehingga&nbsp;</strong>tidak sepenuhnya mencerminkan kerja sama regional.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9121', '1990', '<p>&hellip;keberadaannya bermanfaat&nbsp;<strong>untuk&nbsp;</strong>memberikan dorongan pentingnya kerja sama regional Asia Tenggara</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9122', '1990', '<p>Pertemuan dimaksudkan&nbsp;<strong>agar&nbsp;</strong>suara Asia lebih didengar di PBB dan mendorong kerja sama di bidang ekonomidan sosial antarnegara di Asia.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9123', '1991', '<p>terbentuknya Colombo Plan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9124', '1991', '<p>Maksud terbentuknya Colombo Plan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9125', '1991', '<p>Manfaat Colombo Plan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9126', '1991', '<p>Kerja sana dalam Colombo Plan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9127', '1991', '<p>Peningkatan kerjasama dengan Colombo Plan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9128', '1992', '<p>1</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9129', '1992', '<p>2</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9130', '1992', '<p>3</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9131', '1992', '<p>4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9132', '1992', '<p>5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9133', '1993', '<p>Bathara Indra mengatakan bahwa Mahesa Sura dengan Dewi Tara tidak sebanding sehingga lamaran ditolak.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9134', '1993', '<p>Bathara Indra berkata, &ldquo;Mahesa Sura dengan Dewi Tara tidak sebanding sehingga lamaran ditolak&rdquo;.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9135', '1993', '<p>Bathara Indra mengatakan bahwa Mahesa Sura dengan Dewi Tara tidak sebanding sehingga lamaran mereka ditolak.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9136', '1993', '<p>Tidak bisa, Mahesa Sura dengan Dewi Tara tidaklah sebanding! kami menolak lamarannya! tukas BatharaIndra.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9137', '1993', '<p>Mahesa Sura dengan Dewi Tara tidak sebanding sehingga lamaran ditolak,&rdquo; kata Bathara Indra</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9138', '1994', '<p>orientasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9139', '1994', '<p>pemunculan masalah</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9140', '1994', '<p>komplikasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9141', '1994', '<p>urutan peristiwa</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9142', '1994', '<p>reorientasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9143', '1995', '<p>agama</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9144', '1995', '<p>budaya</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9145', '1995', '<p>estetika</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9146', '1995', '<p>moral</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9147', '1995', '<p>pendidikan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9148', '1996', '<p>konjungsi kausalitas</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9149', '1996', '<p>konjungsi temporal</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9150', '1996', '<p>kata kerja bermakna tindakan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9151', '1996', '<p>kata kerja bemakna perbuatan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9152', '1996', '<p>fungsi keterangan tempat dan waktu</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9153', '1997', '<p>abstrak</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9154', '1997', '<p>orientasi</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9155', '1997', '<p>komplikasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9156', '1997', '<p>evaluasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9157', '1997', '<p>reorientasi</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9158', '1998', '<p>Kata<em> Hormat</em> ditulis dengan huruf kapital dan tanpa tanda apa pun.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9159', '1998', '<p>Kata<em> Hormat</em> diawali dengan huruf kecil dan diikuti tanda<em> titik</em> .</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9160', '1998', '<p>Kata <em>Hormat</em> ditulis dengan huruf kecil tanpa tanda apa pun.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9161', '1998', '<p>Kata<em> Dengan</em> ditulis dengan huruf kecil dan diikuti tanda pisah <em>(-)</em></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9162', '1998', '<p>Kata&nbsp;<em>Hormat&nbsp;</em>diawali dengan huruf kecil dan diikuti tanda koma.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9163', '1999', '<p>kata ganti orang pertama tunggal</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9164', '1999', '<p>kata sapaan orang kedua tunggal</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9165', '1999', '<p>kata ganti orang ketiga tunggal</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9166', '1999', '<p>kata ganti orang pertama jamak</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9167', '1999', '<p>kata ganti orang ketiga tunggal</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9168', '2000', '<p>&ldquo;dengan sebenar-benarnya dan tanpa paksaan&rdquo; dihilangkan; &ldquo;perhatiannya&rdquo; diganti perhatian Bapak/Ibu; dan&ldquo;terimakasih banyak&rdquo; diganti terimakasih.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9169', '2000', '<p>&ldquo;dengan sebenar-benarnya dan tanpa paksaan&rdquo; dihilangkan; &ldquo;perhatiannya&rdquo; diganti perhatian Bapak/Ibu; dan&ldquo;terimakasih banyak&rdquo; diganti terima kasih.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9170', '2000', '<p>&ldquo;tanpa paksaan&rdquo; dihilangkan; &ldquo;perhatiannya&rdquo; diganti perhatian Bapak/Ibu; dan<br />
&ldquo;terimakasih banyak&rdquo; diganti terima kasih.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9171', '2000', '<p>&ldquo;tanpa paksaan&rdquo; dihilangkan; &ldquo;perhatiannya&rdquo; diganti perhatian Bapak/Ibu; dan &ldquo;terimakasih banyak&rdquo; digantiterima kasih sekali.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9172', '2000', '<p>&ldquo;dengan sebenar-benarnya dan tanpa paksaan&rdquo; dihilangkan; &ldquo;perhatiannya&rdquo; diganti perhatian Bapak/Ibu yangsudah diberikan; dan &ldquo;terimakasih banyak&rdquo; diganti terima kasih.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9173', '2001', '<p>pembuka surat lamaran pekerjaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9174', '2001', '<p>isi surat lamaran pekerjaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9175', '2001', '<p>balasan surat lamaran pekerjaan</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9176', '2001', '<p>penutup surat lamaran pekerjaan</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9177', '2001', '<p>ucapan terima kasih dari pelamar</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9178', '2002', '<p>Awal kata rincian ditulis dengan huruf kecil; kata &ldquo;fotocopy&rdquo; diganti &ldquo;foto kopi&rdquo;; kata &ldquo;ijasah&rdquo; diganti &ldquo;ijazah&rdquo;;tanda baca titik koma (;) setelah frasa &ldquo;perjanjian kontrak kerja&rdquo; diganti dengan tanda baca titik (.)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9179', '2002', '<p>Kata &ldquo;fotocopy&rdquo; diganti ditulis miring menjadi &ldquo;fotocopy&rdquo;; kata &ldquo;ijasah&rdquo; diganti &ldquo;ijazah&rdquo;; tanda baca titik koma(;) setelah frasa &ldquo;perjanjian kontrak kerja&rdquo; diganti dengan tanda baca titik (.)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9180', '2002', '<p>Awal kata rincian ditulis dengan huruf kecil; kata &ldquo;fotocopy&rdquo; diganti &ldquo;fotokopi&rdquo;; kata &ldquo;ijasah&rdquo; diganti &ldquo;ijazah&rdquo;;tanda baca titik koma (;) setelah frasa &ldquo;perjanjian kontrak kerja&rdquo; diganti dengan tanda baca titik (.)</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9181', '2002', '<p>Singkatan berupa &ldquo;KTP dan KK&rdquo; harusnya ditulis kapital di awal huruf saja menjadi &ldquo;Ktp dan Kk&rdquo;; kata&ldquo;fotocopy&rdquo; diganti &ldquo;fotokopi&rdquo;; kata &ldquo;ijasah&rdquo; diganti &ldquo;ijazah&rdquo;; tanda baca titik koma (;) setelah frasa &ldquo;perjanjiankontrak kerja&rdquo; diganti dengan tanda baca titik (.)</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9182', '2002', '<p>Awal kata rincian ditulis dengan huruf kecil; kata &ldquo;fotocopy&rdquo; diganti &ldquo;fotokopi&rdquo;; kata &ldquo;ijasah&rdquo; diganti &ldquo;ijazah&rdquo;;tanda baca titik koma (;) setelah rincian seharusnya dihilangkan semua dan diganti dengan tanda titik (.) padaakhir rincian</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9183', '2003', '<p>Semarang, 15-02-2021</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9184', '2003', '<p>Semarang, 15 Februari 2021</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9185', '2003', '<p>Semarang, 15 Feb 2021</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9186', '2003', '<p>Semarang, 15 Pebruari 2021</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9187', '2003', '<p>Semarang, 15-Feb-2021.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9188', '2004', '<p>4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9189', '2004', '<p>5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9190', '2004', '<p>6</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9191', '2004', '<p>7</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9192', '2004', '<p>8</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9193', '2005', '<p><img src=\"[base_url]uploads/topik_93/6274c495409fb.png\" /></p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9194', '2005', '<p><img src=\"[base_url]uploads/topik_93/6274c49c30bcf.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9195', '2005', '<p><img src=\"[base_url]uploads/topik_93/6274c4a227bfa.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9196', '2005', '<p><img src=\"[base_url]uploads/topik_93/6274c4a6d5b4b.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9197', '2005', '<p><img src=\"[base_url]uploads/topik_93/6274c4ab7e534.png\" /></p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9198', '2006', '<p>Kepada<br />
Yth. Pimpinan PT Makmur<br />
di Jl. Wahidin No. 2 Yogyakarta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9199', '2006', '<p>Yth. PT Makmur<br />
di Jalan Wahidin nomor 2<br />
Yogyakarta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9200', '2006', '<p>Kepada Yth. Pimpinan P.T. Makmur<br />
di Jalan Wahidin 2<br />
Yogyakarta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9201', '2006', '<p>Yth. Kepala<br />
PT Makmur<br />
di Jalan Wahidin 2<br />
Daerah Istimewa Yogyakarta</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9202', '2006', '<p>Yth. Pimpinan PT Makmur<br />
di Jalan Wahidin 2<br />
Yogyakarta</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9203', '2007', '<p>Tempat dan tanggal pembuatan surat, lampiran, hal, alamat yang dituju, salam pembuka, paragraf pembuka, isi,paragraf penutup, salam penutup, tanda tangan dan nama terang pengirim.</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9204', '2007', '<p>Tempat dan tanggal pembuatan surat, lampiran, hal, alamat yang dituju, salam pembuka, paragraf pembuka, isi,paragraf penutup, salam penutup, tanda tangan dan nama terang pengirim.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9205', '2007', '<p>Tempat dan tanggal pembuatan surat, lampiran, hal, alamat yang dituju, salam pembuka, paragraf pembuka, isi,paragraf penutup, salam penutup, tanda tangan dan nama terang pengirim.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9206', '2007', '<p>Tempat dan tanggal pembuatan surat, lampiran, hal, alamat yang dituju, salam pembuka, paragraf pembuka, isi,paragraf penutup, salam penutup, tanda tangan dan nama terang pengirim.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9207', '2007', '<p>Tempat dan tanggal pembuatan surat, lampiran, hal, alamat yang dituju, salam pembuka, paragraf pembuka, isi,paragraf penutup, salam penutup, tanda tangan dan nama terang pengirim.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9208', '2008', '<p>Berdasarkan informasi dari koran Kedaulatan Rakyat pada tanggal 1 November 2021 menyatakan lembaga Bapak/Ibu membutuhkan staf pengajar, saya yang bertandatangan di bawah ini:</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9209', '2008', '<p>Melalui informasi dari koran &ldquo;Kedaulatan Rakyat&rdquo; pada tanggal 1 November 2021 menyatakan lembaga Bapak/Ibu membutuhkan staf pengajar, saya yang bertanda tangan di bawah ini</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9210', '2008', '<p>Sehubungan dengan informasi dari Koran Kedaulatan Rakyat pada tanggal 1 November 2021 menyatakanlembaga Bapak/Ibu membutuhkan staf pengajar, saya yang bertandatangan dibawah ini:</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9211', '2008', '<p>Berdasarkan informasi dari koran Kedaulatan Rakyat pada tanggal 1 November 2021 menyatakan lembaga Bapak/Ibu membutuhkan staf pengajar, saya yang bertanda tangan di bawah ini:</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9212', '2008', '<p>Berdasarkan informasi dari koran Kedaulatan Rakyat pada tanggal 1-11-2021 menyatakan lembaga Bapak/Ibu membutuhkan staf pengajar, saya yang bertandatangan dibawah ini.</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9216', '2009', '<p>4</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9217', '2009', '<p>5</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9213', '2009', '<p>1</p>
', 1, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9214', '2009', '<p>2</p>
', 0, 1);**;**;INSERT INTO `cbt_jawaban` (`jawaban_id`, `jawaban_soal_id`, `jawaban_detail`, `jawaban_benar`, `jawaban_aktif`) VALUES ('9215', '2009', '<p>3</p>
', 0, 1);**;**;